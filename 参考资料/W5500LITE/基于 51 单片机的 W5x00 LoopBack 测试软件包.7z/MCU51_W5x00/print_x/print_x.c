/**
  ******************************************************************************
  * @file    print_x.c
  * @author  popctrl@163.com
  * @version V1.0.0
  * @date    2013-04-20
  * @brief   ��ӡ�ַ�����16 ���ƴ�ӡ�ɿ���ʾ�ַ�
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2013 popctrl@163.com</center></h2>
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/

#include "print_x.h"

/*----------------------------------------------------------------------------*/

void prt_str(unsigned char *str);
void prt_hb(unsigned char byte);
void prt_hh(unsigned short halfword);
void prt_hw(unsigned int word);

void test_print_x(void);

/*----------------------------------------------------------------------------*/

void prt_str(unsigned char *str)
{
    while(*str) {
        USART_SendData(EVAL_COM1, (uint8_t) *str);
        while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
        str++;
    }
}

/*----------------------------------------------------------------------------*/

void prt_hb(unsigned char byte)
{
    unsigned char tmp;

    USART_SendData(EVAL_COM1, (uint8_t) '0');
    while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
    USART_SendData(EVAL_COM1, (uint8_t) 'x');
    while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);

    tmp = byte / 0x10;
    if(tmp < 10) {
        tmp += 0x30;
    }
    else {
        tmp += 0x37;
    }
    USART_SendData(EVAL_COM1, (uint8_t) tmp);
    while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
    tmp = byte % 0x10;
    if(tmp < 10) {
        tmp += 0x30;
    }
    else {
        tmp += 0x37;
    }
    USART_SendData(EVAL_COM1, (uint8_t) tmp);
    while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
}

/*----------------------------------------------------------------------------*/

void prt_hh(unsigned short halfword)
{
    unsigned char tmp,i;

    USART_SendData(EVAL_COM1, (uint8_t) '0');
    while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
    USART_SendData(EVAL_COM1, (uint8_t) 'x');
    while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
    for(i = 16; i; i -= 8){
        tmp = ((halfword >> (i-8)) & 0xFF) / 0x10;
        if(tmp < 10) {
            tmp += 0x30;
        }
        else {
            tmp += 0x37;
        }
        USART_SendData(EVAL_COM1, (uint8_t) tmp);
        while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
        tmp = ((halfword >> (i-8)) & 0xFF) % 0x10;
        if(tmp < 10) {
            tmp += 0x30;
        }
        else {
            tmp += 0x37;
        }
        USART_SendData(EVAL_COM1, (uint8_t) tmp);
        while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
    }
}

/*----------------------------------------------------------------------------*/

void prt_hw(unsigned int word)
{
    unsigned char tmp,i;

    USART_SendData(EVAL_COM1, (uint8_t) '0');
    while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
    USART_SendData(EVAL_COM1, (uint8_t) 'x');
    while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);

    for(i = 32; i; i -= 8){
        tmp = ((word >> (i-8)) & 0xFF) / 0x10;
        if(tmp < 10) {
            tmp += 0x30;
        }
        else {
            tmp += 0x37;
        }
        USART_SendData(EVAL_COM1, (uint8_t) tmp);
        while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
        tmp = ((word >> (i-8)) & 0xFF) % 0x10;
        if(tmp < 10) {
            tmp += 0x30;
        }
        else {
            tmp += 0x37;
        }
        USART_SendData(EVAL_COM1, (uint8_t) tmp);
        while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET);
    }
}

/*----------------------------------------------------------------------------*/

void test_print_x(void)
{
    unsigned int i;

    prt_str("\r\n");
    for(i=0; i<256; i++){
      prt_hb(i); prt_str("\r\n");}

    for(i=0xFFFFFFFF; i>0xFFFFFEFF; i--){
      prt_hb(i); prt_str("\r\n");}

    for(i=0; i<256; i++){
      prt_hh(i); prt_str("\r\n");}

    for(i=0xFFFFFFFF; i>0xFFFFFEFF; i--){
      prt_hh(i); prt_str("\r\n");}

    for(i=0; i<256; i++){
      prt_hw(i); prt_str("\r\n");}

    for(i=0xFFFFFFFF; i>0xFFFFFEFF; i--){
      prt_hw(i); prt_str("\r\n");}
}

/*----------------------------------------------------------------------------*/
