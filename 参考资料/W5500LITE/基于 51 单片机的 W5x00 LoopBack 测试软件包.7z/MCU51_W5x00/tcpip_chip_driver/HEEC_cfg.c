/**
  ******************************************************************************
  * @file    HEEC_cfg.c 
  * @author  popctrl@163.com
  * @version V1.0.1
  * @date    2014-05-12
  * @brief   HEEC: Hardwired TCP/IP Embedded Ethernet Controller
  ******************************************************************************
  * @attention
  *
  * SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT 
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM 
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/

#include "HEEC_cfg.h"

/*----------------------------------------------------------------------------*/

uint8  I_STATUS[MAX_SOCK_NUM];
uint16 SMASK[MAX_SOCK_NUM]; /**< Variable for Tx buffer MASK in each channel */
uint16 RMASK[MAX_SOCK_NUM]; /**< Variable for Rx buffer MASK in each channel */
uint16 SSIZE[MAX_SOCK_NUM]; /**< Max Tx buffer size by each channel */
uint16 RSIZE[MAX_SOCK_NUM]; /**< Max Rx buffer size by each channel */
// uint16 SBUFBASEADDRESS[MAX_SOCK_NUM]; /**< Tx buffer base address by each channel */
// uint16 RBUFBASEADDRESS[MAX_SOCK_NUM]; /**< Rx buffer base address by each channel */
uint32 SBUFBASEADDRESS[MAX_SOCK_NUM]; /**< Tx buffer base address by each channel */
uint32 RBUFBASEADDRESS[MAX_SOCK_NUM]; /**< Rx buffer base address by each channel */
uint8  SUBNET[4];

uint8 TX_BUF[TX_RX_MAX_BUF_SIZE];
uint8 RX_BUF[TX_RX_MAX_BUF_SIZE];

//uint8 ch_status[MAX_SOCK_NUM] = {0,0,0,0,0,0,0,0}; /** 0:close, 1:ready, 2:connected */
uint8 ch_status[MAX_SOCK_NUM] = {0,}; /** 0:close, 1:ready, 2:connected */

_TCPIP_CHIP TCPIP_CHIP;

/*----------------------------------------------------------------------------*/

void Set_network(void);

void setGAR(uint8 *addr);       //�������ص�ַ
void setSUBR(uint8 *addr);      //������������
void saveSUBR(uint8 *addr);     //������������
void setSHAR(uint8 *addr);      //���ñ���������ַ
void setSIPR(uint8 *addr);      //���ñ���IP��ַ
void setRTR(uint16 timeout);
void setRCR(uint8 retry);
void setIMR(uint8 mask);

void HEEC_sysinit(uint8 *tx_size, uint8 *rx_size);

void vHEEC_WrBuf(unsigned long addr, unsigned char * pBuf, unsigned short len);
void vHEEC_RdBuf(unsigned long addr, unsigned char * pBuf, unsigned short len);

/*----------------------------------------------------------------------------*/
void vHEEC_CRITICAL_ENTER(void)
{

}
/*----------------------------------------------------------------------------*/
void vHEEC_CRITICAL_EXIT(void)
{

}
/*----------------------------------------------------------------------------*/



/*----------------------------------------------------------------------------*/
void Set_network(void)
{
    //uint8 tmp_array[6];
    unsigned char i;

    // GateWay ADDRESS
    for (i = 0 ; i < 4; i++) Config_Msg.Gw[i] = GatewayIP[i];
    // Subnet Mask ADDRESS
    for (i = 0 ; i < 4; i++) Config_Msg.Sub[i] = SubMask[i];
    // MAC ADDRESS
    for (i = 0 ; i < 6; i++) Config_Msg.Mac[i] = MAC[i];
    // Local IP ADDRESS
    for (i = 0 ; i < 4; i++) Config_Msg.Lip[i] = IPaddr[i];

//    setGAR(Config_Msg.Gw);
//    setSUBR(Config_Msg.Sub);
//    saveSUBR(Config_Msg.Sub);
//    setSHAR(Config_Msg.Mac);
//    setSIPR(Config_Msg.Lip);
    setGAR(GatewayIP);
    setSUBR(SubMask);
    saveSUBR(SubMask);
    setSHAR(MAC);
    setSIPR(IPaddr);

    // Set DHCP
    Config_Msg.DHCP = Enable_DHCP;
    // Destination IP address for TCP Client
    for (i = 0 ; i < 4; i++) Chconfig_Type_Def.destip[i] = DestIP[i];
    Chconfig_Type_Def.port = DestPORT;

    //Set RTR and RCR register
    setRTR(6000);
    //setRTR(0x7D0);
    setRCR(0x03);

#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
    //vHEEC_WrReg(HEEC_PHYCFGR,0xB8);
#endif

    //Init HEEC TX & RX Memory size
    HEEC_sysinit(HEECtxsize, HEECrxsize);

}

/*----------------------------------------------------------------------------*/
/**
@brief  Sets up gateway IP address.
*/
void setGAR(uint8 *addr) // a pointer to a 4 -byte array responsible to set the Gateway IP address.
{
#if ((__TCPIP_CHIP_TYPE__ == __CHIP_W5100__) || (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__))
    vHEEC_WrReg((HEEC_GAR0 + 0),addr[0]);
    vHEEC_WrReg((HEEC_GAR0 + 1),addr[1]);
    vHEEC_WrReg((HEEC_GAR0 + 2),addr[2]);
    vHEEC_WrReg((HEEC_GAR0 + 3),addr[3]);
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
    vHEEC_WrReg((HEEC_GAR0 + 0),addr[0]);
    vHEEC_WrReg((HEEC_GAR0 + (1<<8)),addr[1]);
    vHEEC_WrReg((HEEC_GAR0 + (2<<8)),addr[2]);
    vHEEC_WrReg((HEEC_GAR0 + (3<<8)),addr[3]);
#endif
}
/*----------------------------------------------------------------------------*/
/**
@brief  Sets up Subnet Mask address.
*/
void setSUBR(uint8 *addr)
{
#if ((__TCPIP_CHIP_TYPE__ == __CHIP_W5100__) || (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__))
    vHEEC_WrReg((HEEC_SUBR0 + 0), addr[0]);
    vHEEC_WrReg((HEEC_SUBR0 + 1), addr[1]);
    vHEEC_WrReg((HEEC_SUBR0 + 2), addr[2]);
    vHEEC_WrReg((HEEC_SUBR0 + 3), addr[3]);
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
    vHEEC_WrReg((HEEC_SUBR0 + 0), addr[0]);
    vHEEC_WrReg((HEEC_SUBR0 + (uint32)(1<<8)), addr[1]);
    vHEEC_WrReg((HEEC_SUBR0 + (uint32)(2<<8)), addr[2]);
    vHEEC_WrReg((HEEC_SUBR0 + (uint32)(3<<8)), addr[3]);
#endif
}
/*----------------------------------------------------------------------------*/
/**
@brief  Save SubnetMask address.
*/
void saveSUBR(uint8 *addr) // a pointer to a 4 -byte array responsible to set the SubnetMask address
{
//#if ((__TCPIP_CHIP_TYPE__ == __CHIP_W5100__) || (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__))
    SUBNET[0] = addr[0];
    SUBNET[1] = addr[1];
    SUBNET[2] = addr[2];
    SUBNET[3] = addr[3];
//#endif
}
/*----------------------------------------------------------------------------*/
/**
@brief  Sets up MAC address.
*/
void setSHAR(uint8 *addr) // a pointer to a 6 -byte array responsible to set the MAC address.
{
#if ((__TCPIP_CHIP_TYPE__ == __CHIP_W5100__) || (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__))
    vHEEC_WrReg((HEEC_SHAR0 + 0),addr[0]);
    vHEEC_WrReg((HEEC_SHAR0 + 1),addr[1]);
    vHEEC_WrReg((HEEC_SHAR0 + 2),addr[2]);
    vHEEC_WrReg((HEEC_SHAR0 + 3),addr[3]);
    vHEEC_WrReg((HEEC_SHAR0 + 4),addr[4]);
    vHEEC_WrReg((HEEC_SHAR0 + 5),addr[5]);
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
    vHEEC_WrReg((HEEC_SHAR0 + 0),addr[0]);
    vHEEC_WrReg((HEEC_SHAR0 + (uint32)(1<<8)),addr[1]);
    vHEEC_WrReg((HEEC_SHAR0 + (uint32)(2<<8)),addr[2]);
    vHEEC_WrReg((HEEC_SHAR0 + (uint32)(3<<8)),addr[3]);
    vHEEC_WrReg((HEEC_SHAR0 + (uint32)(4<<8)),addr[4]);
    vHEEC_WrReg((HEEC_SHAR0 + (uint32)(5<<8)),addr[5]);
#endif
}
/*----------------------------------------------------------------------------*/
/**
@brief  Sets up Source IP address.
*/
void setSIPR(uint8 *addr) // a pointer to a 4 -byte array responsible to set the Source IP address.
{
#if ((__TCPIP_CHIP_TYPE__ == __CHIP_W5100__) || (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__))
    vHEEC_WrReg((HEEC_SIPR0 + 0),addr[0]);
    vHEEC_WrReg((HEEC_SIPR0 + 1),addr[1]);
    vHEEC_WrReg((HEEC_SIPR0 + 2),addr[2]);
    vHEEC_WrReg((HEEC_SIPR0 + 3),addr[3]);
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
    vHEEC_WrReg((HEEC_SIPR0 + 0),addr[0]);
    vHEEC_WrReg((HEEC_SIPR0 + (uint32)(1<<8)),addr[1]);
    vHEEC_WrReg((HEEC_SIPR0 + (uint32)(2<<8)),addr[2]);
    vHEEC_WrReg((HEEC_SIPR0 + (uint32)(3<<8)),addr[3]);
#endif
}

/*----------------------------------------------------------------------------*/
/**
 Retransmittion
 **/
/*----------------------------------------------------------------------------*/
/**
@brief  Sets up Retransmission time.

If there is no response from the peer or delay in response then retransmission
will be there as per RTR (Retry Time-value Register)setting
*/
void setRTR(uint16 timeout)
{
#if ((__TCPIP_CHIP_TYPE__ == __CHIP_W5100__) || (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__))
    vHEEC_WrReg(HEEC_RTR,(uint8)((timeout & 0xff00) >> 8));
    vHEEC_WrReg((HEEC_RTR + 1),(uint8)(timeout & 0x00ff));
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
    vHEEC_WrReg(HEEC_RTR,(uint8)((timeout & 0xff00) >> 8));
    vHEEC_WrReg((HEEC_RTR + (uint32)(1<<8)),(uint8)(timeout & 0x00ff));
#endif
}

/**
@brief  Set the number of Retransmission.

If there is no response from the peer or delay in response then recorded time
as per RTR & RCR register seeting then time out will occur.
*/
void setRCR(uint8 retry)
{
    vHEEC_WrReg(HEEC_RCR,retry);
}

/*----------------------------------------------------------------------------*/

void setMR(uint8 val)
{
    vHEEC_WrReg(HEEC_MR,val);
}

/*----------------------------------------------------------------------------*/

/**
@brief  This function set the interrupt mask Enable/Disable appropriate Interrupt. ('1' : interrupt enable)

If any bit in IMR is set as '0' then there is not interrupt signal though the bit is
set in IR register.
*/
void setIMR(uint8 mask)
{
    vHEEC_WrReg(HEEC_IMR,mask); // must be setted 0x10.
}

/*----------------------------------------------------------------------------*/

/**
@brief  This function set the transmit & receive buffer size as per the channels is used
Note for TMSR and RMSR bits are as follows\n
bit 1-0 : memory size of channel #0 \n
bit 3-2 : memory size of channel #1 \n
bit 5-4 : memory size of channel #2 \n
bit 7-6 : memory size of channel #3 \n
bit 9-8 : memory size of channel #4 \n
bit 11-10 : memory size of channel #5 \n
bit 12-12 : memory size of channel #6 \n
bit 15-14 : memory size of channel #7 \n
Maximum memory size for Tx, Rx in the W5200 is 16K Bytes,\n
In the range of 16KBytes, the memory size could be allocated dynamically by each channel.\n
Be attentive to sum of memory size shouldn't exceed 8Kbytes\n
and to data transmission and receiption from non-allocated channel may cause some problems.\n
If the 16KBytes memory is already  assigned to centain channel, \n
other 3 channels couldn't be used, for there's no available memory.\n
If two 4KBytes memory are assigned to two each channels, \n
other 2 channels couldn't be used, for there's no available memory.\n
*/
void HEEC_sysinit(uint8 *tx_size, uint8 *rx_size)
{
    /*------------------------------------------------------------------------*/
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)

    int16 i, tmp;
    int16 ssum, rsum;

#ifdef USE_PRINT_X_DBG
    prt_str("HEEC_sysinit().\r\n");
#endif

    tmp = 0;
    for(i = 0 ; i < MAX_SOCK_NUM; i++){
        tmp += (rx_size[i]<<(i*2));
    }
    vHEEC_WrReg(HEEC_RMSR, 0x55);
    tmp = 0;
    for(i = 0 ; i < MAX_SOCK_NUM; i++){
        tmp += (tx_size[i]<<(i*2));
    }
    vHEEC_WrReg(HEEC_TMSR, 0x55);

    ssum = 0;
    rsum = 0;

    SBUFBASEADDRESS[0] = (uint16)(__DEF_IINCHIP_MAP_TXBUF__);       /* Set base address of Tx memory for channel #0 */
    RBUFBASEADDRESS[0] = (uint16)(__DEF_IINCHIP_MAP_RXBUF__);       /* Set base address of Rx memory for channel #0 */

    for(i = 0 ; i < MAX_SOCK_NUM; i++){       // Set the size, masking and base address of Tx & Rx memory by each channel
//         vHEEC_WrReg((HEEC_Sn_TXMEM_SIZE(i)),tx_size[i]);
//         vHEEC_WrReg((HEEC_Sn_RXMEM_SIZE(i)),rx_size[i]);

#ifdef USE_PRINT_X_DBG
        //printf("Sn_TXMEM_SIZE = %d\r\n",IINCHIP_READ(Sn_TXMEM_SIZE(i)));
        //printf("Sn_RXMEM_SIZE = %d\r\n",IINCHIP_READ(Sn_RXMEM_SIZE(i)));
#endif

        SSIZE[i] = (int16)(0);
        RSIZE[i] = (int16)(0);

        if( ssum <= 8192 ){
            switch( tx_size[i] ){
                case 1:
                    SSIZE[i] = (int16)(1024);
                    SMASK[i] = (uint16)(0x03FF);
                    break;
                case 2:
                    SSIZE[i] = (int16)(2048);
                    SMASK[i] = (uint16)(0x07FF);
                    break;
                case 4:
                    SSIZE[i] = (int16)(4096);
                    SMASK[i] = (uint16)(0x0FFF);
                    break;
                case 8:
                    SSIZE[i] = (int16)(8192);
                    SMASK[i] = (uint16)(0x1FFF);
                    break;
            }
        }
        if( rsum <= 8192 ){
            switch( rx_size[i] ){
                case 1:
                    RSIZE[i] = (int16)(1024);
                    RMASK[i] = (uint16)(0x03FF);
                    break;
                case 2:
                    RSIZE[i] = (int16)(2048);
                    RMASK[i] = (uint16)(0x07FF);
                    break;
                case 4:
                    RSIZE[i] = (int16)(4096);
                    RMASK[i] = (uint16)(0x0FFF);
                    break;
                case 8:
                    RSIZE[i] = (int16)(8192);
                    RMASK[i] = (uint16)(0x1FFF);
                    break;
            }
        }
        ssum += SSIZE[i];
        rsum += RSIZE[i];

        if (i != 0){ // Sets base address of Tx and Rx memory for channel #1,#2,#3
            SBUFBASEADDRESS[i] = SBUFBASEADDRESS[i-1] + SSIZE[i-1];
            RBUFBASEADDRESS[i] = RBUFBASEADDRESS[i-1] + RSIZE[i-1];
        }
#ifdef USE_PRINT_X_DBG
        //prt_str("ch = %d\r\n",i);
        //printf("SBUFBASEADDRESS = %d\r\n",(uint16)SBUFBASEADDRESS[i]);
        //printf("RBUFBASEADDRESS = %d\r\n",(uint16)RBUFBASEADDRESS[i]);
        //printf("SSIZE = %d\r\n",SSIZE[i]);
        //printf("RSIZE = %d\r\n",RSIZE[i]);
#endif
    }
#endif
    /*------------------------------------------------------------------------*/
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)

    int16 i;
    int16 ssum,rsum;

#ifdef USE_PRINT_X_DBG
    prt_str("HEEC_sysinit().\r\n");
#endif

    ssum = 0;
    rsum = 0;

    SBUFBASEADDRESS[0] = (uint16)(__DEF_IINCHIP_MAP_TXBUF__);       /* Set base address of Tx memory for channel #0 */
    RBUFBASEADDRESS[0] = (uint16)(__DEF_IINCHIP_MAP_RXBUF__);       /* Set base address of Rx memory for channel #0 */

    for(i = 0 ; i < MAX_SOCK_NUM; i++){       // Set the size, masking and base address of Tx & Rx memory by each channel
        vHEEC_WrReg((HEEC_Sn_TXMEM_SIZE(i)),tx_size[i]);
        vHEEC_WrReg((HEEC_Sn_RXMEM_SIZE(i)),rx_size[i]);

#ifdef USE_PRINT_X_DBG
        //printf("Sn_TXMEM_SIZE = %d\r\n",IINCHIP_READ(Sn_TXMEM_SIZE(i)));
        //printf("Sn_RXMEM_SIZE = %d\r\n",IINCHIP_READ(Sn_RXMEM_SIZE(i)));
#endif

        SSIZE[i] = (int16)(0);
        RSIZE[i] = (int16)(0);

        if( ssum <= 16384 ){
            switch( tx_size[i] ){
                case 1:
                    SSIZE[i] = (int16)(1024);
                    SMASK[i] = (uint16)(0x03FF);
                    break;
                case 2:
                    SSIZE[i] = (int16)(2048);
                    SMASK[i] = (uint16)(0x07FF);
                    break;
                case 4:
                    SSIZE[i] = (int16)(4096);
                    SMASK[i] = (uint16)(0x0FFF);
                    break;
                case 8:
                    SSIZE[i] = (int16)(8192);
                    SMASK[i] = (uint16)(0x1FFF);
                    break;
                case 16:
                    SSIZE[i] = (int16)(16384);
                    SMASK[i] = (uint16)(0x3FFF);
                break;
            }
        }

        if( rsum <= 16384 ){
            switch( rx_size[i] ){
                case 1:
                    RSIZE[i] = (int16)(1024);
                    RMASK[i] = (uint16)(0x03FF);
                    break;
                case 2:
                    RSIZE[i] = (int16)(2048);
                    RMASK[i] = (uint16)(0x07FF);
                    break;
                case 4:
                    RSIZE[i] = (int16)(4096);
                    RMASK[i] = (uint16)(0x0FFF);
                    break;
                case 8:
                    RSIZE[i] = (int16)(8192);
                    RMASK[i] = (uint16)(0x1FFF);
                    break;
                case 16:
                    RSIZE[i] = (int16)(16384);
                    RMASK[i] = (uint16)(0x3FFF);
                    break;
            }
        }
        ssum += SSIZE[i];
        rsum += RSIZE[i];

        if (i != 0){ // Sets base address of Tx and Rx memory for channel #1,#2,#3
            SBUFBASEADDRESS[i] = SBUFBASEADDRESS[i-1] + SSIZE[i-1];
            RBUFBASEADDRESS[i] = RBUFBASEADDRESS[i-1] + RSIZE[i-1];
        }
#ifdef USE_PRINT_X_DBG
        //prt_str("ch = %d\r\n",i);
        //printf("SBUFBASEADDRESS = %d\r\n",(uint16)SBUFBASEADDRESS[i]);
        //printf("RBUFBASEADDRESS = %d\r\n",(uint16)RBUFBASEADDRESS[i]);
        //printf("SSIZE = %d\r\n",SSIZE[i]);
        //printf("RSIZE = %d\r\n",RSIZE[i]);
#endif
    }

#endif
    /*------------------------------------------------------------------------*/
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)

    int16 i;
    int16 ssum,rsum;

#ifdef USE_PRINT_X_DBG
    prt_str("HEEC_sysinit().\r\n");
#endif

    ssum = 0;
    rsum = 0;

//     SBUFBASEADDRESS[0] = (uint16)(__DEF_IINCHIP_MAP_TXBUF__);       /* Set base address of Tx memory for channel #0 */
//     RBUFBASEADDRESS[0] = (uint16)(__DEF_IINCHIP_MAP_RXBUF__);       /* Set base address of Rx memory for channel #0 */

    for(i = 0 ; i < MAX_SOCK_NUM; i++){       // Set the size, masking and base address of Tx & Rx memory by each channel
        vHEEC_WrReg((HEEC_Sn_TXMEM_SIZE(i)),tx_size[i]);
        vHEEC_WrReg((HEEC_Sn_RXMEM_SIZE(i)),rx_size[i]);

        SSIZE[i] = (int16)(0);
        RSIZE[i] = (int16)(0);

        if( ssum <= 16384 ){
            switch( tx_size[i] ){
                case 1:
                    SSIZE[i] = (int16)(1024);
                    SMASK[i] = (uint16)(0x03FF);
                    break;
                case 2:
                    SSIZE[i] = (int16)(2048);
                    SMASK[i] = (uint16)(0x07FF);
                    break;
                case 4:
                    SSIZE[i] = (int16)(4096);
                    SMASK[i] = (uint16)(0x0FFF);
                    break;
                case 8:
                    SSIZE[i] = (int16)(8192);
                    SMASK[i] = (uint16)(0x1FFF);
                    break;
                case 16:
                    SSIZE[i] = (int16)(16384);
                    SMASK[i] = (uint16)(0x3FFF);
                break;
            }
        }

        if( rsum <= 16384 ){
            switch( rx_size[i] ){
                case 1:
                    RSIZE[i] = (int16)(1024);
                    RMASK[i] = (uint16)(0x03FF);
                    break;
                case 2:
                    RSIZE[i] = (int16)(2048);
                    RMASK[i] = (uint16)(0x07FF);
                    break;
                case 4:
                    RSIZE[i] = (int16)(4096);
                    RMASK[i] = (uint16)(0x0FFF);
                    break;
                case 8:
                    RSIZE[i] = (int16)(8192);
                    RMASK[i] = (uint16)(0x1FFF);
                    break;
                case 16:
                    RSIZE[i] = (int16)(16384);
                    RMASK[i] = (uint16)(0x3FFF);
                    break;
            }
        }
        ssum += SSIZE[i];
        rsum += RSIZE[i];

        //SBUFBASEADDRESS[i] = (uint32)((i*0x0800)+(WIZCHIP_TXBUF_BLOCK(i)<<3) + _W5500_SPI_WRITE_);       /* Set base address of Tx memory for channel #0 */
//         SBUFBASEADDRESS[i] = (uint32)(((i*0x0000)<<8)+(WIZCHIP_TXBUF_BLOCK(i)<<3));       /* Set base address of Tx memory for channel #0 */
//         RBUFBASEADDRESS[i] = (uint32)(((i*0x0000)<<8)+(WIZCHIP_RXBUF_BLOCK(i)<<3));       /* Set base address of Rx memory for channel #0 */
        SBUFBASEADDRESS[i] = (uint32)((0x000000FF&(WIZCHIP_TXBUF_BLOCK(i)<<3)));       /* Set base address of Tx memory for channel #0 */
        RBUFBASEADDRESS[i] = (uint32)((0x000000FF&(WIZCHIP_RXBUF_BLOCK(i)<<3)));       /* Set base address of Rx memory for channel #0 */

#ifdef USE_PRINT_X_DBG
        //printf("Sn_TXMEM_SIZE = %d\r\n",IINCHIP_READ(Sn_TXMEM_SIZE(i)));
        //printf("Sn_RXMEM_SIZE = %d\r\n",IINCHIP_READ(Sn_RXMEM_SIZE(i)));
#endif

#ifdef USE_PRINT_X_DBG
        //prt_str("ch = %d\r\n",i);
        //printf("SBUFBASEADDRESS = %d\r\n",(uint16)SBUFBASEADDRESS[i]);
        //printf("RBUFBASEADDRESS = %d\r\n",(uint16)RBUFBASEADDRESS[i]);
        //printf("SSIZE = %d\r\n",SSIZE[i]);
        //printf("RSIZE = %d\r\n",RSIZE[i]);
#endif
    }
#endif
    /*------------------------------------------------------------------------*/
#if (__TCPIP_CHIP_TYPE__ == __CHIP_CH395Q__)

#endif

}

/*----------------------------------------------------------------------------*/

void vHEEC_WrBuf(unsigned long addr, unsigned char * pBuf, unsigned short len)
{
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)

#endif

#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)

#endif

#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
   uint16_t i = 0;
   uint16_t j = 0;
   vHEEC_CRITICAL_ENTER();
   vHEEC_SPI_CS_LOW();

#if( (_WIZCHIP_IO_MODE_ & _WIZCHIP_IO_MODE_SPI_))

   #if  ( _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_SPI_VDM_ )
      addr |= (_W5500_SPI_WRITE_ | _W5500_SPI_VDM_OP_);
      TCPIP_CHIP.IF.SPI._write_byte((addr & 0x00FF0000) >> 16);
      TCPIP_CHIP.IF.SPI._write_byte((addr & 0x0000FF00) >>  8);
      TCPIP_CHIP.IF.SPI._write_byte((addr & 0x000000FF) >>  0);
      for(i = 0; i < len; i++, j)
         TCPIP_CHIP.IF.SPI._write_byte(pBuf[i]);
   #elif( _WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_SPI_FDM_ )
      AddrSel |= (_W5500_SPI_WRITE_ | _W5500_SPI_FDM_OP_LEN4_);
      for(i = 0; i < len/4; i++)
      {
         TCPIP_CHIP.IF.SPI._write_byte((addr & 0x00FF0000) >> 16);
         TCPIP_CHIP.IF.SPI._write_byte((addr & 0x0000FF00) >>  8);
         TCPIP_CHIP.IF.SPI._write_byte((addr & 0x000000FF) >>  0);
         TCPIP_CHIP.IF.SPI._write_byte(pBuf[i*4]  );
         TCPIP_CHIP.IF.SPI._write_byte(pBuf[i*4+1]);
         TCPIP_CHIP.IF.SPI._write_byte(pBuf[i*4+2]);
         TCPIP_CHIP.IF.SPI._write_byte(pBuf[i*4+3]);
         //AddrSel += (4 << 8);    // offset address + 4
         AddrSel = TCPIP_CHIP_OFFSET_INC(addr,4);
      }
      len %= 4;      // for the rest data
      if(len)
      {
         addr -= 1;  // change _W5500_SPI_FDM_OP_LEN4_ to _W5500_SPI_FDM_OP_LEN2_
         i *= 4;
         for(j = 0; j < len/2 ; j++)
         {
            TCPIP_CHIP.IF.SPI._write_byte((addr & 0x00FF0000) >> 16);
            TCPIP_CHIP.IF.SPI._write_byte((addr & 0x0000FF00) >>  8);
            TCPIP_CHIP.IF.SPI._write_byte((addr & 0x000000FF) >>  0);
            TCPIP_CHIP.IF.SPI._write_byte(pBuf[i]  );
            TCPIP_CHIP.IF.SPI._write_byte(pBuf[i+1]);
            i += 2;
            //AddrSel += (2 << 8);    // offset address + 2
            AddrSel = TCPIP_CHIP_OFFSET_INC(addr, 2);
         }
         len %= 2;
         if(len)
         {
            AddrSel -= 1;  // change _W5500_SPI_FDM_OP_LEN2_ to _W5500_SPI_FDM_OP_LEN1_
            TCPIP_CHIP.IF.SPI._write_byte((addr & 0x00FF0000) >> 16);
            TCPIP_CHIP.IF.SPI._write_byte((addr & 0x0000FF00) >>  8);
            TCPIP_CHIP.IF.SPI._write_byte((addr & 0x000000FF) >>  0);
            TCPIP_CHIP.IF.SPI._write_byte(pBuf[i]);
         }
      }
   #else
      #error "Unsupported _WIZCHIP_IO_SPI_ in W5500 !!!"
   #endif

#elif ( (_WIZCHIP_IO_MODE_ & _WIZCHIP_IO_MODE_BUS_) )

   #if  (_WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_BUS_DIR_)

   #elif(_WIZCHIP_IO_MODE_ == _WIZCHIP_IO_MODE_BUS_INDIR_)

   #else
      #error "Unsupported _WIZCHIP_IO_MODE_BUS_ in W5500 !!!"
   #endif
#else
   #error "Unknown _WIZCHIP_IO_MODE_ in W5500. !!!!"
#endif

   vHEEC_SPI_CS_HIGH();
   vHEEC_CRITICAL_EXIT();
#endif


#if (__TCPIP_CHIP_TYPE__ == __CHIP_CH395Q__)
#endif

}

/*----------------------------------------------------------------------------*/

void vHEEC_RdBuf(unsigned long addr, unsigned char * pBuf, unsigned short len)
{
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_CH395Q__)
#endif
}

/********************** (C) COPYRIGHT 2014 popctrl@163.com *****END OF FILE****/
