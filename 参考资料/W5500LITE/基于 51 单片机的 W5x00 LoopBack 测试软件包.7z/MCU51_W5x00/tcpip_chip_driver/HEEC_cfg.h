/**
  ******************************************************************************
  * @file    HEEC_cfg.h 
  * @author  popctrl@163.com
  * @version V1.0.0
  * @date    2013-11-06
  * @brief   HEEC: Hardwired TCP/IP Embedded Ethernet Controller
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2013 popctrl@163.com</center></h2>
  *
  *
  ******************************************************************************
  */

#ifndef _HEEC_CFG_H_
#define _HEEC_CFG_H_

#ifdef __cplusplus
extern "C" {
#endif 

/*----------------------------------------------------------------------------*/

//#include <stdio.h>
//#include <math.h>
//#include "slct_EVB.h"
#include "use_mcu_types.h"
#include "tcpip_chip_types.h"
#include "net_msg_cfg.h"
#include "tcpip_chip_spi_ctrl.h"

#ifdef USE_PRINT_X_DBG
  #include "print_x.h"
#endif

/*----------------------------------------------------------------------------*/

/** global define */
#define FW_VERSION      0x01010000  /* System F/W Version : 1.1.0.0 */
#define HW_VERSION      0x01000000

#define TX_RX_MAX_BUF_SIZE  128

//#define TX_BUF  0x1100
//#define RX_BUF  (TX_BUF+TX_RX_MAX_BUF_SIZE)

/*----------------------------------------------------------------------------*/

/*********************************************************
* TCP/IP CHIP BASIC IF functions for SPI, UART ETC.
*********************************************************/
typedef struct __TCPIP_CHIP
{
   unsigned char   id[6];
   unsigned short  if_mode;

   struct _CRIS
   {
      void (*_enter)  (void);
      void (*_exit) (void);
   } CRIS;
   struct _CS
   {
      void (*_select)  (void);
      void (*_deselect)(void);
   } CS;
   union
   {
      struct _BUS
      {
         unsigned char (*_read_byte) (unsigned long addr);
         void (*_write_byte) (unsigned long addr, unsigned char udata);
      } BUS;
      struct _SPI
      {
         unsigned char (*_read_byte) (void);
         void (*_write_byte) (unsigned char udata);
      } SPI;
      // To be added
      //
   } IF;
} _TCPIP_CHIP;

extern _TCPIP_CHIP  TCPIP_CHIP;


/*----------------------------------------------------------------------------*/

extern uint8  I_STATUS[MAX_SOCK_NUM];
extern uint16 SMASK[MAX_SOCK_NUM]; /**< Variable for Tx buffer MASK in each channel */
extern uint16 RMASK[MAX_SOCK_NUM]; /**< Variable for Rx buffer MASK in each channel */
extern uint16 SSIZE[MAX_SOCK_NUM]; /**< Max Tx buffer size by each channel */
extern uint16 RSIZE[MAX_SOCK_NUM]; /**< Max Rx buffer size by each channel */
// extern uint16 SBUFBASEADDRESS[MAX_SOCK_NUM]; /**< Tx buffer base address by each channel */
// extern uint16 RBUFBASEADDRESS[MAX_SOCK_NUM]; /**< Rx buffer base address by each channel */
extern uint32 SBUFBASEADDRESS[MAX_SOCK_NUM]; /**< Tx buffer base address by each channel */
extern uint32 RBUFBASEADDRESS[MAX_SOCK_NUM]; /**< Rx buffer base address by each channel */
extern uint8  SUBNET[4];

extern uint8 TX_BUF[TX_RX_MAX_BUF_SIZE];
extern uint8 RX_BUF[TX_RX_MAX_BUF_SIZE];

extern uint8 ch_status[MAX_SOCK_NUM];

/*----------------------------------------------------------------------------*/

extern void Set_network(void);

extern void setGAR(uint8 *addr);       //�������ص�ַ
extern void setSUBR(uint8 *addr);      //������������
extern void setSHAR(uint8 *addr);      //���ñ���������ַ
extern void setSIPR(uint8 *addr);      //���ñ���IP��ַ
extern void setRTR(uint16 timeout);
extern void setRCR(uint8 retry);
extern void setMR(uint8 val);
extern void setIMR(uint8 mask);

extern void HEEC_sysinit(uint8 *tx_size, uint8 *rx_size);

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif      /* _TCPIP_CHIP_TYPE_H_ */
