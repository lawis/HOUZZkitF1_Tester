/**
  ******************************************************************************
  * @file    net_msg_cfg.c 
  * @author  popctrl@163.com
  * @version V0.1
  * @date    2014-05-11
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/

#include "net_msg_cfg.h"

/*----------------------------------------------------------------------------*/

unsigned char code IPaddr[4] = {192, 168, 2, 20};
unsigned char code GatewayIP[4] = {192, 168, 2, 1};
unsigned char code SubMask[4] = {255, 255, 255, 0};
unsigned char code MAC[6] = {0, 8, 0xDC, 1, 2, 5};

/* For TCP Client */
/* Configuration Network Information of TEST PC */
unsigned char code DestIP[4] = {192, 168, 2, 222};   /* DST_IP Address*/
unsigned short code DestPORT = 5004;                 /* DST_IP port */

unsigned char Enable_DHCP = OFF;

CONFIG_MSG Config_Msg;
CHCONFIG_TYPE_DEF Chconfig_Type_Def; 



#if   (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)
  /* TX MEM SIZE- SOCKET 0-3: 2KB */
  /* RX MEM SIZE- SOCKET 0-3: 2KB */
  unsigned char HEECtxsize[MAX_SOCK_NUM] = {2,2,2,2};
  unsigned char HEECrxsize[MAX_SOCK_NUM] = {2,2,2,2};
#endif

#if   (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)
  /* TX MEM SIZE- SOCKET 0-7: 2KB */
  /* RX MEM SIZE- SOCKET 0-7: 2KB */
  unsigned char HEECtxsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};
  unsigned char HEECrxsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};
#endif

#if   (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
  /* TX MEM SIZE- SOCKET 0-7: 2KB */
  /* RX MEM SIZE- SOCKET 0-7: 2KB */
  unsigned char HEECtxsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};
  unsigned char HEECrxsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};
#endif

#if   (__TCPIP_CHIP_TYPE__ == __CHIP_CH395Q__)
  /* TX MEM SIZE- SOCKET 0-7: 2KB */
  /* RX MEM SIZE- SOCKET 0-7: 2KB */
  unsigned char HEECtxsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};
  unsigned char HEECrxsize[MAX_SOCK_NUM] = {2,2,2,2,2,2,2,2};
#endif

/********************** (C) COPYRIGHT 2014 popctrl@163.com *****END OF FILE****/
