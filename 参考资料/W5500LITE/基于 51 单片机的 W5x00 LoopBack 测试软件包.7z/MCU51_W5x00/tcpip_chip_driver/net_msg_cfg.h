/**
  ******************************************************************************
  * @file    net_msg_cfg.h 
  * @author  popctrl@163.com
  * @version V1.0.1
  * @date    2014-01-03
  * @brief   ������Ϣ���ö���
  ******************************************************************************
  * @attention
  *
  * SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT 
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM 
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  ******************************************************************************
  */

#ifndef _NET_MSG_CFG_H_
#define _NET_MSG_CFG_H_

#ifdef __cplusplus
extern "C" {
#endif 

/*----------------------------------------------------------------------------*/

#include "tcpip_chip_types.h"

/*----------------------------------------------------------------------------*/
#if   (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)
  #define MAX_SOCK_NUM    4   /* Maxmium number of socket */
#endif
#if   (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)
  #define MAX_SOCK_NUM    8   /* Maxmium number of socket */
#endif
#if   (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
  #define MAX_SOCK_NUM    8   /* Maxmium number of socket */
#endif
#if   (__TCPIP_CHIP_TYPE__ == __CHIP_CH395Q__)
  #define MAX_SOCK_NUM    8   /* Maxmium number of socket */
#endif


#define SOCK_CONFIG     2   /* UDP */
#define SOCK_DNS        2   /* UDP */
#define SOCK_DHCP       3   /* UDP */

#define MAX_BUF_SIZE    1460
#define KEEP_ALIVE_TIME 30  /* 30sec */

#define ON          1
#define OFF         0

#define HIGH        1
#define LOW         0

/* SRAM address range is 0x2000 0000 ~ 0x2000 4FFF (20KB) */
#define HEEC_TX_RX_MAX_BUF_SIZE  2048
/* #define TX_BUF    0x20004000 */
/* #define RX_BUF    (TX_BUF+TX_RX_MAX_BUF_SIZE) */
/* #define ApplicationAddress  0x08004000 */

/*----------------------------------------------------------------------------*/

typedef struct _CONFIG_MSG
{
    unsigned char Mac[6];
    unsigned char Lip[4];
    unsigned char Sub[4];
    unsigned char Gw[4];
    unsigned char DNS_Server_IP[4];
    unsigned char DHCP;
} CONFIG_MSG;


typedef struct _CONFIG_TYPE_DEF
{
    unsigned short port;
    unsigned char destip[4];
} CHCONFIG_TYPE_DEF;

/*----------------------------------------------------------------------------*/

extern unsigned char code IPaddr[4];
extern unsigned char code GatewayIP[4];
extern unsigned char code SubMask[4];
extern unsigned char code MAC[6];
extern unsigned char Enable_DHCP;
extern unsigned char code DestIP[4];
extern unsigned short code DestPORT;

extern unsigned char Enable_DHCP;

extern unsigned char HEEC_TX_BUF[HEEC_TX_RX_MAX_BUF_SIZE];
extern unsigned char HEEC_RX_BUF[HEEC_TX_RX_MAX_BUF_SIZE];

extern CONFIG_MSG Config_Msg;
extern CHCONFIG_TYPE_DEF Chconfig_Type_Def; 

extern unsigned char HEECtxsize[MAX_SOCK_NUM];
extern unsigned char HEECrxsize[MAX_SOCK_NUM];

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif      /* _NET_MSG_CFG_H_ */

/********************** (C) COPYRIGHT 2014 popctrl@163.com *****END OF FILE****/
