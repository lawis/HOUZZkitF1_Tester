/**
  ******************************************************************************
  * @file    socket_w5x00.h 
  * @author  popctrl@163.com
  * @version V1.0.0
  * @date    2014-01-08
  * @brief   
  ******************************************************************************
  * @attention
  *
  * SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT 
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM 
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  ******************************************************************************
  */

#ifndef _SOCKET_W5X00_H_
#define _SOCKET_W5X00_H_

#ifdef __cplusplus
extern "C" {
#endif 

/*----------------------------------------------------------------------------*/

#include <stdio.h>
#include "use_mcu_types.h"
#include "tcpip_chip_types.h"
#include "tcpip_chip_spi_ctrl.h"
#include "net_msg_cfg.h"
#include "HEEC_cfg.h"
#include "w5x00.h"
/*----------------------------------------------------------------------------*/

extern uint8 socket(SOCKET s, uint8 protocol, uint16 port, uint8 flag); // Opens a socket(TCP or UDP or IP_RAW mode)
extern void close(SOCKET s); // Close socket
extern uint8 connect(SOCKET s, uint8 * addr, uint16 port); // Establish TCP connection (Active connection)
extern void disconnect(SOCKET s); // disconnect the connection
extern uint8 listen(SOCKET s);  // Establish TCP connection (Passive connection)
extern uint16 send(SOCKET s, const uint8 * buf, uint16 len, bool retry); // Send data (TCP)
extern uint16 recv(SOCKET s, uint8 * buf, uint16 len);  // Receive data (TCP)
extern uint16 sendto(SOCKET s, const uint8 * buf, uint16 len, uint8 * addr, uint16 port); // Send data (UDP/IP RAW)
extern uint16 recvfrom(SOCKET s, uint8 * buf, uint16 len, uint8 * addr, uint16  *port); // Receive data (UDP/IP RAW)

extern uint16 igmpsend(SOCKET s, const uint8 * buf, uint16 len);


#ifdef __cplusplus
}
#endif

#endif      /* _SOCKET_W5X00_H_ */

/********************** (C) COPYRIGHT 2014 popctrl@163.com *****END OF FILE****/
