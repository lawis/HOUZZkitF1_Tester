/**
  ******************************************************************************
  * @file    tcpip_chip_spi_ctrl.c 
  * @author  popctrl@163.com
  * @version V0.1
  * @date    2014-05-12
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/

#include "tcpip_chip_spi_ctrl.h"

/*----------------------------------------------------------------------------*/
volatile unsigned long my_time;
volatile unsigned long presentTime;

/*----------------------------------------------------------------------------*/

void HEEC_RST_LowLevel_Init(void);
void HEEC_Reset(void);
void vHEEC_SPI_LowLevel_Init(void);
void vHEEC_SPI_HighLevel_Init(void);
void vHEEC_SPI_init(void);

unsigned char ucHEEC_WrRdByte(unsigned char udata);

void vHEEC_WrByte(unsigned char udata);
void vHEEC_WrReg(unsigned long addr, unsigned char udata);

unsigned char ucHEEC_RdByte(void);
unsigned char ucHEEC_RdReg(unsigned long addr);


static void  HEEC_spi_delay(unsigned int count);

void Delay_us( unsigned char time_us );
void Delay_ms( unsigned short time_ms );
unsigned long time_return(void);
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/

unsigned char ucHEEC_WrRdByte(unsigned char udata)
{
    unsigned char i, tmp=0;
    for(i=0; i<8; i++){
        SPI_SCK = 0;
        if((udata << i) & 0x80){
            SPI_MOSI=1;
        }
        else{
            SPI_MOSI=0;
        }
        tmp <<= 1;
        tmp |= SPI_MISO;
        SPI_SCK = 1;
    }
    SPI_SCK = 0;
    return tmp;       
}

/*----------------------------------------------------------------------------*/

void vHEEC_WrByte(unsigned char udata)
{
    unsigned char i;
    for(i=0; i<8; i++){
        SPI_SCK = 0;
        if((udata << i) & 0x80){
            SPI_MOSI=1;
        }
        else{
            SPI_MOSI=0;
        }
        SPI_SCK = 1;
    }
    SPI_SCK = 0;
}

/*----------------------------------------------------------------------------*/

void vHEEC_WrReg(unsigned long addr, unsigned char udata)
{
    vHEEC_SPI_CS_LOW();
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)
    vHEEC_WrByte(HEEC_OP_Code_RD);
    vHEEC_WrByte((unsigned char)((addr & 0xFF00) >> 8));
    vHEEC_WrByte((unsigned char)(addr & 0x00FF));
    vcHEEC_WrByte( udata );
#endif
    /* */
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)
    vHEEC_WrByte((unsigned char)((addr & 0xFF00) >> 8));
    vHEEC_WrByte((unsigned char)(addr & 0x00FF));
    vcHEEC_WrByte(HEEC_OP_Code_WR);
    vcHEEC_WrByte((unsigned char)0x01);
    vcHEEC_WrByte( udata );
#endif
    /* */
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
    vHEEC_WrByte((unsigned char)((addr & 0xFF0000) >> 16));
    vHEEC_WrByte((unsigned char)((addr & 0x00FF00) >> 8));
    vHEEC_WrByte((unsigned char)((addr & 0x0000F8) + 0x04));
    vHEEC_WrByte((unsigned char) udata );
#endif

#if (__TCPIP_CHIP_TYPE__ == __CHIP_CH395Q__)

#endif
    vHEEC_SPI_CS_HIGH();
}

/*----------------------------------------------------------------------------*/

unsigned char ucHEEC_RdByte(void)
{
    unsigned char i, tmp;

    for(i=0; i<8; i++){
        SPI_SCK = 0;
        tmp <<= 1;
        tmp |= SPI_MISO;
        SPI_SCK = 1;
    }
    SPI_SCK = 0;
    return tmp;
}

/*----------------------------------------------------------------------------*/

unsigned char ucHEEC_RdReg(unsigned long addr)
{
    unsigned char tmp;
    vHEEC_SPI_CS_LOW();
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)
    vHEEC_WrByte(HEEC_OP_Code_RD);
    vHEEC_WrByte((unsigned char)((addr & 0xFF00) >> 8));
    vHEEC_WrByte((unsigned char)(addr & 0x00FF));
    tmp = ucHEEC_RdByte();
#endif
    /* */
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)
    vHEEC_WrByte((unsigned char)((addr & 0xFF00) >> 8));
    vHEEC_WrByte((unsigned char)(addr & 0x00FF));
    vHEEC_WrByte(HEEC_OP_Code_RD);
    vHEEC_WrByte((unsigned char)0x01);
    tmp = ucHEEC_RdByte();
#endif
    /* */
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
    vHEEC_WrByte((unsigned char)((addr & 0xFF0000) >> 16));
    vHEEC_WrByte((unsigned char)((addr & 0x00FF00) >> 8));
    vHEEC_WrByte((unsigned char)((addr & 0x0000F8) + 0x00));
    tmp = ucHEEC_RdByte();
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_CH395Q__)

#endif
    vHEEC_SPI_CS_HIGH();
    return tmp;
}

/*----------------------------------------------------------------------------*/

void HEEC_RST_LowLevel_Init(void)
{

}

/*----------------------------------------------------------------------------*/

void HEEC_Reset(void)
{
    volatile unsigned char i;
    vHEEC_RSTB_LOW();
    for(i=0; i<255; i++);
    for(i=0; i<255; i++);
    for(i=0; i<255; i++);
    vHEEC_RSTB_HIGH();
    for(i=0; i<255; i++);
}

/*----------------------------------------------------------------------------*/

void vHEEC_SPI_init(void)
{
    vHEEC_SPI_LowLevel_Init();
}

/*----------------------------------------------------------------------------*/
static void  HEEC_spi_delay(unsigned int count)
{
	volatile unsigned int i;
	for (i = 0; i < count ; i++);
}
/*----------------------------------------------------------------------------*/

void vHEEC_SPI_LowLevel_Init(void)
{

}

/*----------------------------------------------------------------------------*/

void vHEEC_SPI_HighLevel_Init(void)
{

}
/*----------------------------------------------------------------------------*/

/*******************************************************************************
* Function Name  : Delay_us
* Description    : Delay per micro second.
* Input          : time_us
* Output         : None
* Return         : None
*******************************************************************************/

void Delay_us( unsigned char time_us )
{
  volatile unsigned char i, j;
  for( i=0;i<time_us;i++ )    
  {
    for( j=0;j<8;j++ )          // 64CLK
    {

    }      
  }                     // 64CLK => 1us
}

/*******************************************************************************
* Function Name  : Delay_ms
* Description    : Delay per mili second.
* Input          : time_ms
* Output         : None
* Return         : None
*******************************************************************************/

void Delay_ms( unsigned short time_ms )
{
  volatile unsigned short i;
  for( i=0;i<time_ms;i++ )
  {
    Delay_us(250);
    Delay_us(250);
    Delay_us(250);
    Delay_us(250);
  }
}

/*----------------------------------------------------------------------------*/
/*******************************************************************************
* Function Name  : time_return
* Description    :  
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/

unsigned long time_return(void) 
{
  //extern uint32_t my_time; 
  return my_time;
}
/*----------------------------------------------------------------------------*/

