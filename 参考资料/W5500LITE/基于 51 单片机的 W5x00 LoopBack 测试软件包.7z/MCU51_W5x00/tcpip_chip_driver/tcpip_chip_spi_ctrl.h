/**
  ******************************************************************************
  * @file    tcpip_chip_spi_ctrl.h 
  * @author  popctrl@163.com
  * @version V0.1
  * @date    2014/05/12
  * @brief   HEEC: Hardwired TCP/IP Embedded Ethernet Controller
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2013 popctrl@163.com</center></h2>
  *
  ******************************************************************************
  */

#ifndef __TCPIP_CHIP_SPI_CTRL_H__
#define __TCPIP_CHIP_SPI_CTRL_H__

#ifdef __cplusplus
 extern "C" {
#endif 

/*----------------------------------------------------------------------------*/
#include	"REG52.h"
#include	<INTRINS.H>

#include "use_mcu_types.h"
#include "tcpip_chip_types.h"

#ifdef USE_PRINT_X_DBG
  #include "print_x.h"
#endif

/*----------------------------------------------------------------------------*/

#define CS_ENABLE           1
#define CS_DISABLE          0

/*----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------*/
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)
// #define HEEC_DLY_1MS       500     //p -> 25uS
// #define HEEC_DLY_1MS       20000   //p -> 475uS
  #define HEEC_DLY_1MS       42000   //p -> 1000uS

  #define HEEC_OP_Code_WR    0xF0
  #define HEEC_OP_Code_RD    0x0F

#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)
// #define HEEC_DLY_1MS       500     //p -> 25uS
// #define HEEC_DLY_1MS       20000   //p -> 475uS
  #define HEEC_DLY_1MS       42000   //p -> 1000uS

  #define HEEC_OP_Code_WR    0x80
  #define HEEC_OP_Code_RD    0x00

#endif

#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
// #define HEEC_DLY_1MS       500     //p -> 25uS
// #define HEEC_DLY_1MS       20000   //p -> 475uS
  #define HEEC_DLY_1MS       42000   //p -> 1000uS

#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_CH395Q__)
// #define HEEC_DLY_1MS       500     //p -> 25uS
// #define HEEC_DLY_1MS       20000   //p -> 475uS
  #define HEEC_DLY_1MS       42000   //p -> 1000uS

#endif

/*----------------------------------------------------------------------------*/
#if (__MCU_TYPE__ == __MCU_8051__)
    sbit    W5x00_RST = P1^3;	//RST
    sbit    SPI_CS = P1^4;  	//SCS
    sbit    SPI_SCK = P1^5; 	//SCLK
    sbit    SPI_MISO = P1^6;  	//MISO
    sbit    SPI_MOSI = P1^7;  	//MOSI

    /* Select TCPIP_CHIP: Select pin low */
    #define vHEEC_SPI_CS_LOW()      SPI_CS = 0
    /* Deselect TCPIP_CHIP: Select pin high */
    #define vHEEC_SPI_CS_HIGH()     SPI_CS = 1

    /* Select HEEC_RSTB: Set pin low */
    #define vHEEC_RSTB_LOW()         W5x00_RST = 0
    /* Deselect HEEC_RSTB: Set pin high */
    #define vHEEC_RSTB_HIGH()        W5x00_RST = 1

#endif

/*----------------------------------------------------------------------------*/

extern volatile unsigned long my_time;
extern volatile unsigned long presentTime;


/*----------------------------------------------------------------------------*/

//extern void HEEC_Delay(void);
extern void HEEC_RST_LowLevel_Init(void);
extern void HEEC_Reset(void);
extern void vHEEC_SPI_LowLevel_Init(void);
extern void vHEEC_SPI_HighLevel_Init(void);
extern void vHEEC_SPI_init(void);
//extern unsigned char SPI_WR_1BYTE(unsigned char udata);

extern unsigned char ucHEEC_WrRdByte(unsigned char udata);

extern void vHEEC_WrByte(unsigned char udata);
extern void vHEEC_WrReg(unsigned long addr, unsigned char udata);

extern unsigned char ucHEEC_RdReg(unsigned long addr);

extern void Delay_us( unsigned char time_us );
extern void Delay_ms( unsigned short time_ms );
extern unsigned long time_return(void);

/*----------------------------------------------------------------------------*/

#define IINCHIP_WRITE(addr, udata) vHEEC_WrReg(addr, udata)
#define IINCHIP_READ( addr ) ucHEEC_RdReg( addr )

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif  /* __TCPIP_CHIP_SPI_CTRL_H__ */
