/**
  ******************************************************************************
  * @file    tcpip_chip_types.h 
  * @author  popctrl@163.com
  * @version V1.0.1
  * @date    2014-01-03
  * @brief   
  ******************************************************************************
  * @attention
  *
  * SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT 
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM 
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  ******************************************************************************
  */

#ifndef _TCPIP_CHIP_TYPES_H_
#define _TCPIP_CHIP_TYPES_H_

#ifdef __cplusplus
extern "C" {
#endif 

/*----------------------------------------------------------------------------*/
/* attribute for TCP/IP Chip ( types, ... )                                   */
/*----------------------------------------------------------------------------*/

#define __CHIP_W5100__          1
#define __CHIP_W5200__          2
#define __CHIP_W5500__          3
#define __CHIP_CH395Q__         4

#define __TCPIP_CHIP_TYPE__     __CHIP_W5500__

/*----------------------------------------------------------------------------*/

#define __DEF_IINCHIP_DIRECT_MODE__     1
#define __DEF_IINCHIP_INDIRECT_MODE__   2
#define __DEF_IINCHIP_SPI_MODE__        3

//#define __DEF_IINCHIP_BUS__     __DEF_IINCHIP_DIRECT_MODE__
//#define __DEF_IINCHIP_BUS__     __DEF_IINCHIP_INDIRECT_MODE__
#define __DEF_IINCHIP_BUS__     __DEF_IINCHIP_SPI_MODE__ /*Enable SPI_mode*/

/*----------------------------------------------------------------------------*/

/**
@brief   __DEF_IINCHIP_MAP_xxx__ : define memory map for iinchip 
*/
#define __DEF_IINCHIP_MAP_BASE__ 0x8000

#if (__DEF_IINCHIP_BUS__ == __DEF_IINCHIP_DIRECT_MODE__)
  #define COMMON_BASE __DEF_IINCHIP_MAP_BASE__
#else
  #define COMMON_BASE 0x0000
#endif

  #define _WIZCHIP_IO_MODE_NONE_         0x0000
  #define _WIZCHIP_IO_MODE_BUS_          0x0100 /**< Bus interface mode */
  #define _WIZCHIP_IO_MODE_SPI_          0x0200 /**< SPI interface mode */

  #define _WIZCHIP_IO_MODE_BUS_DIR_      (_WIZCHIP_IO_MODE_BUS_ + 1) /**< BUS interface mode for direct  */
  #define _WIZCHIP_IO_MODE_BUS_INDIR_    (_WIZCHIP_IO_MODE_BUS_ + 2) /**< BUS interface mode for indirect */

#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)
  #define __DEF_IINCHIP_MAP_TXBUF__     (COMMON_BASE + 0x4000) /* Internal Tx buffer address of the iinchip */
  #define __DEF_IINCHIP_MAP_RXBUF__     (COMMON_BASE + 0x6000) /* Internal Rx buffer address of the iinchip */
#endif

#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)
  #define __DEF_IINCHIP_MAP_TXBUF__     (COMMON_BASE + 0x8000) /* Internal Tx buffer address of the iinchip */
  #define __DEF_IINCHIP_MAP_RXBUF__     (COMMON_BASE + 0xC000) /* Internal Rx buffer address of the iinchip */
#endif

#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
  #define _W5500_SPI_VDM_OP_          0x00
  #define _W5500_SPI_FDM_OP_LEN1_     0x01
  #define _W5500_SPI_FDM_OP_LEN2_     0x02
  #define _W5500_SPI_FDM_OP_LEN4_     0x03

  #define _WIZCHIP_IO_MODE_SPI_VDM_         (_WIZCHIP_IO_MODE_SPI_ + 1) /**< SPI interface mode for variable length data*/
  #define _WIZCHIP_IO_MODE_SPI_FDM_         (_WIZCHIP_IO_MODE_SPI_ + 2) /**< SPI interface mode for fixed length data mode*/

  #define _WIZCHIP_IO_MODE_                 _WIZCHIP_IO_MODE_SPI_VDM_
  #define __DEF_IINCHIP_MAP_TXBUF__     (COMMON_BASE + 0x0000) /* Internal Tx buffer address of the iinchip */
  #define __DEF_IINCHIP_MAP_RXBUF__     (COMMON_BASE + 0x0000) /* Internal Rx buffer address of the iinchip */
#endif
/*----------------------------------------------------------------------------*/

#ifndef NULL
  #define NULL        ((void *) 0)
#endif

/*----------------------------------------------------------------------------*/

typedef enum { false, true } bool;

#ifndef _SIZE_T
#define _SIZE_T
typedef unsigned int size_t;
#endif

/**
 * The 8-bit signed data type.
 */
typedef char int8;
/**
 * The volatile 8-bit signed data type.
 */
typedef volatile char vint8;
/**
 * The 8-bit unsigned data type.
 */
typedef unsigned char uint8;
/**
 * The volatile 8-bit unsigned data type.
 */
typedef volatile unsigned char vuint8;

/**
 * The 16-bit signed data type.
 */
typedef int int16;
/**
 * The volatile 16-bit signed data type.
 */
typedef volatile int vint16;
/**
 * The 16-bit unsigned data type.
 */
//typedef unsigned int uint16;
typedef unsigned short uint16;
/**
 * The volatile 16-bit unsigned data type.
 */
typedef volatile unsigned int vuint16;
/**
 * The 32-bit signed data type.
 */
typedef long int32;
/**
 * The volatile 32-bit signed data type.
 */
typedef volatile long vint32;
/**
 * The 32-bit unsigned data type.
 */
typedef unsigned long uint32;
/**
 * The volatile 32-bit unsigned data type.
 */
typedef volatile unsigned long vuint32;

/* bsd */
typedef uint8           u_char;     /**< 8-bit value */
typedef uint8           SOCKET;
typedef uint16          u_short;    /**< 16-bit value */
typedef uint16          u_int;      /**< 16-bit value */
typedef uint32          u_long;     /**< 32-bit value */

typedef union _un_l2cval {
    u_long  lVal;
    u_char  cVal[4];
}un_l2cval;

typedef union _un_i2cval {
    u_int   iVal;
    u_char  cVal[2];
}un_i2cval;

/*----------------------------------------------------------------------------*/

#if   (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)
  #include "w5100.h"
#elif (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)
  #include "w5200.h"
#elif (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
  #include "w5500.h"
#elif (__TCPIP_CHIP_TYPE__ == __CHIP_CH395Q__)
  #include "ch395q.h"
#else 
  #error "Unknown defined __TCPIP_CHIP_TYPE__. You should define one of W5100, W5200, W5500, and CH395Q !"
#endif


/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif      /* _TCPIP_CHIP_TYPES_H_ */

/********************** (C) COPYRIGHT 2014 popctrl@163.com *****END OF FILE****/
