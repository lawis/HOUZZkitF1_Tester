/**
  ******************************************************************************
  * @file    use_mcu_types.h 
  * @author  popctrl@163.com
  * @version V0.1
  * @date    2014-05-12
  * @brief   
  ******************************************************************************
  * @attention
  *
  * SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT 
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM 
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  ******************************************************************************
  */

#ifndef _USE_MCU_TYPES_H_
#define _USE_MCU_TYPES_H_

#ifdef __cplusplus
extern "C" {
#endif 

/*----------------------------------------------------------------------------*/
/* attribute for mcu ( types, ... )                                           */
/*----------------------------------------------------------------------------*/

#define __MCU_8051__            1
#define __MCU_STM32F407__       2
#define __MCU_NUC120RE3AN__     3
#define __MCU_STM32F103R__      4

#define __MCU_TYPE__            __MCU_8051__

/*----------------------------------------------------------------------------*/

#define _ENDIAN_LITTLE_     0   /**<  This must be defined if system is little-endian alignment */
#define _ENDIAN_BIG_        1
#define SYSTEM_ENDIAN       _ENDIAN_LITTLE_

#define CLK_CPU             8000000     /**< 8Mhz(for serial) */

/* ## __DEF_IINCHIP_xxx__ : define option for iinchip driver *****************/
// #define __DEF_IINCHIP_DBG__ /* involve debug code in driver (socket.c) */
#define __DEF_IINCHIP_INT__ /**< involve interrupt service routine (socket.c) */
// #define __DEF_IINCHIP_PPP__ /* involve pppoe routine (socket.c) */
                            /* If it is defined, the source files(md5.h,md5.c) must be included in your project.
                               Otherwize, the source files must be removed in your project. */

/*----------------------------------------------------------------------------*/

#if (__MCU_TYPE__ == __MCU_STM32F407__)
      #define IINCHIP_ISR_DISABLE()
      #define IINCHIP_ISR_ENABLE()  
      #define IINCHIP_ISR_GET(X)
      #define IINCHIP_ISR_SET(X)
#elif (__MCU_TYPE__ == __MCU_STM32F103R__)
      #define IINCHIP_ISR_DISABLE()
      #define IINCHIP_ISR_ENABLE()  
      #define IINCHIP_ISR_GET(X)
      #define IINCHIP_ISR_SET(X)
#elif (__MCU_TYPE__ == __MCU_8051__)
      #define IINCHIP_ISR_DISABLE()
      #define IINCHIP_ISR_ENABLE()  
      #define IINCHIP_ISR_GET(X)
      #define IINCHIP_ISR_SET(X)
#else
    #error "unknown MCU type"
#endif

/*----------------------------------------------------------------------------*/

#if (__MCU_TYPE__ == __MCU_STM32F407__)

#elif (__MCU_TYPE__ == __MCU_STM32F103R__)

#elif (__MCU_TYPE__ == __MCU_8051__)
  #include	"REG52.h"
  #include	<INTRINS.H>
#endif

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif      /* _USE_MCU_TYPES_H_ */

/********************** (C) COPYRIGHT 2014 popctrl@163.com *****END OF FILE****/
