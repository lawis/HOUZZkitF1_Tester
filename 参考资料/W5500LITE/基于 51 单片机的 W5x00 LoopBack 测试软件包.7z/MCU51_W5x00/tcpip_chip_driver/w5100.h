/**
  ******************************************************************************
  * @file    w5100.h 
  * @author  popctrl@163.com
  * @version V1.0.0
  * @date    2013-11-05
  * @brief   HEEC: Hardwired TCP/IP Embedded Ethernet Controller
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2013 popctrl@163.com</center></h2>
  *
  ******************************************************************************
  */

#ifndef _W5100_H_
#define _W5100_H_

#ifdef __cplusplus
extern "C" {
#endif


#define W5100_MR                (COMMON_BASE + 0x0000)
#define HEEC_MR                 W5100_MR
/**
 @brief Gateway IP Register address
 */
#define W5100_GAR0              (COMMON_BASE + 0x0001)
#define HEEC_GAR0               W5100_GAR0
/**
 @brief Subnet mask Register address
 */
#define W5100_SUBR0             (COMMON_BASE + 0x0005)
#define HEEC_SUBR0              W5100_SUBR0
/**
 @brief Source MAC Register address
 */
#define W5100_SHAR0             (COMMON_BASE + 0x0009)
#define HEEC_SHAR0              W5100_SHAR0
/**
 @brief Source IP Register address
 */
#define W5100_SIPR0             (COMMON_BASE + 0x000F)
#define HEEC_SIPR0              W5100_SIPR0
/**
 @brief Interrupt Register
 */
#define W5100_IR                (COMMON_BASE + 0x0015)
#define HEEC_IR                 W5100_IR
/**
 @brief Interrupt mask register
 */
#define W5100_IMR               (COMMON_BASE + 0x0016)
#define HEEC_IMR                W5100_IMR
/**
 @brief Timeout register address( 1 is 100us )
 */
#define W5100_RTR               (COMMON_BASE + 0x0017)
#define HEEC_RTR                W5100_RTR
/**
 @brief Retry count reigster
 */
#define W5100_RCR               (COMMON_BASE + 0x0019)
#define HEEC_RCR                W5100_RCR
/**
 @brief Receive memory size reigster
 */
#define W5100_RMSR              (COMMON_BASE + 0x001A)
#define HEEC_RMSR               W5100_RMSR
/**
 @brief Transmit memory size reigster
 */
#define W5100_TMSR              (COMMON_BASE + 0x001B)
#define HEEC_TMSR               W5100_TMSR
/**
 @brief Authentication type register address in PPPoE mode
 */
#define W5100_PATR0             (COMMON_BASE + 0x001C)
#define HEEC_PATR0              W5100_PATR0

//#define PPPALGO (COMMON_BASE + 0x001D)
#define W5100_PTIMER            (COMMON_BASE + 0x0028)
#define HEEC_PTIMER             W5100_PTIMER

#define W5100_PMAGIC            (COMMON_BASE + 0x0029)
#define HEEC_PMAGIC             W5100_PMAGIC

/**
 @brief Unreachable IP register address in UDP mode
 */
#define W5100_UIPR0             (COMMON_BASE + 0x002A)
#define HEEC_UIPR0              W5100_UIPR0

/**
 @brief Unreachable Port register address in UDP mode
 */
#define W5100_UPORT0            (COMMON_BASE + 0x002E)
#define HEEC_UPORT0             W5100_UPORT0

/**
 @brief socket register
*/
#define CH_BASE                 (COMMON_BASE + 0x0400)
#define HEEC_CH_BASE            CH_BASE
/**
 @brief size of each channel register map
 */
#define CH_SIZE                 0x0100
#define HEEC_CH_SIZE            CH_SIZE
/**
 @brief socket Mode register
 */
#define Sn_MR(ch)               (CH_BASE + ch * CH_SIZE + 0x0000)
#define HEEC_Sn_MR(ch)          Sn_MR(ch)
/**
 @brief channel Sn_CR register
 */
#define Sn_CR(ch)               (CH_BASE + ch * CH_SIZE + 0x0001)
#define HEEC_Sn_CR(ch)          Sn_CR(ch)
/**
 @brief channel interrupt register
 */
#define Sn_IR(ch)               (CH_BASE + ch * CH_SIZE + 0x0002)
#define HEEC_Sn_IR(ch)          Sn_IR(ch)
/**
 @brief channel status register
 */
#define Sn_SR(ch)               (CH_BASE + ch * CH_SIZE + 0x0003)
#define HEEC_Sn_SR(ch)          Sn_SR(ch)
/**
 @brief source port register
 */
#define Sn_PORT0(ch)            (CH_BASE + ch * CH_SIZE + 0x0004)
#define HEEC_Sn_PORT0(ch)       Sn_PORT0(ch)
/**
 @brief Peer MAC register address
 */
#define Sn_DHAR0(ch)            (CH_BASE + ch * CH_SIZE + 0x0006)
#define HEEC_Sn_DHAR0(ch)       Sn_DHAR0(ch)
/**
 @brief Peer IP register address
 */
#define Sn_DIPR0(ch)            (CH_BASE + ch * CH_SIZE + 0x000C)
#define HEEC_Sn_DIPR0(ch)       Sn_DIPR0(ch)
/**
 @brief Peer port register address
 */
#define Sn_DPORT0(ch)           (CH_BASE + ch * CH_SIZE + 0x0010)
#define HEEC_Sn_DPORT0(ch)      Sn_DPORT0(ch)
/**
 @brief Maximum Segment Size(Sn_MSSR0) register address
 */
#define Sn_MSSR0(ch)            (CH_BASE + ch * CH_SIZE + 0x0012)
#define HEEC_Sn_MSSR0(ch)       Sn_MSSR0(ch)
/**
 @brief Protocol of IP Header field register in IP raw mode
 */
#define Sn_PROTO(ch)            (CH_BASE + ch * CH_SIZE + 0x0014)
#define HEEC_Sn_PROTO(ch)       Sn_PROTO(ch)
/**
 @brief IP Type of Service(TOS) Register
 */
#define Sn_TOS(ch)              (CH_BASE + ch * CH_SIZE + 0x0015)
#define HEEC_Sn_TOS(ch)         Sn_TOS(ch)
/**
 @brief IP Time to live(TTL) Register
 */
#define Sn_TTL(ch)              (CH_BASE + ch * CH_SIZE + 0x0016)
#define HEEC_Sn_TTL(ch)         Sn_TTL(ch)
/**
 @brief Transmit free memory size register
 */
#define Sn_TX_FSR0(ch)          (CH_BASE + ch * CH_SIZE + 0x0020)
#define HEEC_Sn_TX_FSR0(ch)     Sn_TX_FSR0(ch)
/**
 @brief Transmit memory read pointer register address
 */
#define Sn_TX_RD0(ch)           (CH_BASE + ch * CH_SIZE + 0x0022)
#define HEEC_Sn_TX_RD0(ch)      Sn_TX_RD0(ch)
/**
 @brief Transmit memory write pointer register address
 */
#define Sn_TX_WR0(ch)           (CH_BASE + ch * CH_SIZE + 0x0024)
#define HEEC_Sn_TX_WR0(ch)      Sn_TX_WR0(ch)
/**
 @brief Received data size register
 */
#define Sn_RX_RSR0(ch)          (CH_BASE + ch * CH_SIZE + 0x0026)
#define HEEC_Sn_RX_RSR0(ch)     Sn_RX_RSR0(ch)
/**
 @brief Read point of Receive memory
 */
#define Sn_RX_RD0(ch)           (CH_BASE + ch * CH_SIZE + 0x0028)
#define HEEC_Sn_RX_RD0(ch)      Sn_RX_RD0(ch)
/**
 @brief Write point of Receive memory
 */
#define Sn_RX_WR0(ch)           (CH_BASE + ch * CH_SIZE + 0x002A)
#define HEEC_Sn_RX_WR0(ch)      Sn_RX_WR0(ch)



/* MODE register values */
#define W5100_MR_RST            0x80        /**< reset */
#define HEEC_MR_RST             W5100_MR_RST
#define W5100_MR_PB             0x10        /**< ping block */
#define HEEC_MR_PB              W5100_MR_PB
#define W5100_MR_PPPOE          0x08        /**< enable pppoe */
#define HEEC_MR_PPPOE           W5100_MR_PPPOE
#define W5100_MR_LB             0x04        /**< little or big endian selector in indirect mode */
#define HEEC_MR_LB              W5100_MR_LB
#define W5100_MR_AI             0x02        /**< auto-increment in indirect mode */
#define HEEC_MR_AI              W5100_MR_AI
#define W5100_MR_IND            0x01        /**< enable indirect mode */
#define HEEC_MR_IND             W5100_MR_IND

/* IR register values */
#define W5100_IR_CONFLICT       0x80        /**< check ip confict */
#define HEEC_IR_CONFLICT        W5100_IR_CONFLICT
#define W5100_IR_UNREACH        0x40        /**< get the destination unreachable message in UDP sending */
#define HEEC_IR_UNREACH         W5100_IR_UNREACH
#define W5100_IR_PPPoE          0x20        /**< get the PPPoE close message */
#define HEEC_IR_PPPoE           W5100_IR_PPPoE
#define W5100_IR_SOCK(ch)       (0x01<<ch)  /**< check socket interrupt */
#define HEEC_IR_SOCK(ch)        W5100_IR_SOCK(ch)

/* Sn_MR values */
#define W5100_Sn_MR_CLOSE       0x00        /**< unused socket */
#define HEEC_Sn_MR_CLOSE        W5100_Sn_MR_CLOSE
#define W5100_Sn_MR_TCP         0x01        /**< TCP */
#define HEEC_Sn_MR_TCP          W5100_Sn_MR_TCP
#define W5100_Sn_MR_UDP         0x02        /**< UDP */
#define HEEC_Sn_MR_UDP          W5100_Sn_MR_UDP
#define W5100_Sn_MR_IPRAW       0x03        /**< IP LAYER RAW SOCK */
#define HEEC_Sn_MR_IPRAW        W5100_Sn_MR_IPRAW
#define W5100_Sn_MR_MACRAW      0x04        /**< MAC LAYER RAW SOCK */
#define HEEC_Sn_MR_MACRAW       W5100_Sn_MR_MACRAW
#define W5100_Sn_MR_PPPOE       0x05        /**< PPPoE */
#define HEEC_Sn_MR_PPPOE        W5100_Sn_MR_PPPOE
#define W5100_Sn_MR_ND          0x20        /**< No Delayed Ack(TCP) flag */
#define HEEC_Sn_MR_ND           W5100_Sn_MR_ND
#define W5100_Sn_MR_MULTI       0x80        /**< support multicating */
#define HEEC_Sn_MR_MULTI        W5100_Sn_MR_MULTI


/* Sn_CR values */
#define W5100_Sn_CR_OPEN        0x01        /**< initialize or open socket */
#define HEEC_Sn_CR_OPEN         W5100_Sn_CR_OPEN
#define W5100_Sn_CR_LISTEN      0x02        /**< wait connection request in tcp mode(Server mode) */
#define HEEC_Sn_CR_LISTEN       W5100_Sn_CR_LISTEN
#define W5100_Sn_CR_CONNECT     0x04        /**< send connection request in tcp mode(Client mode) */
#define HEEC_Sn_CR_CONNECT      W5100_Sn_CR_CONNECT
#define W5100_Sn_CR_DISCON      0x08        /**< send closing reqeuset in tcp mode */
#define HEEC_Sn_CR_DISCON       W5100_Sn_CR_DISCON
#define W5100_Sn_CR_CLOSE       0x10        /**< close socket */
#define HEEC_Sn_CR_CLOSE        W5100_Sn_CR_CLOSE
#define W5100_Sn_CR_SEND        0x20        /**< updata txbuf pointer, send data */
#define HEEC_Sn_CR_SEND         W5100_Sn_CR_SEND
#define W5100_Sn_CR_SEND_MAC    0x21        /**< send data with MAC address, so without ARP process */
#define HEEC_Sn_CR_SEND_MAC     W5100_Sn_CR_SEND_MAC
#define W5100_Sn_CR_SEND_KEEP   0x22        /**<  send keep alive message */
#define HEEC_Sn_CR_SEND_KEEP    W5100_Sn_CR_SEND_KEEP
#define W5100_Sn_CR_RECV        0x40        /**< update rxbuf pointer, recv data */
#define HEEC_Sn_CR_RECV         W5100_Sn_CR_RECV

#ifdef __DEF_IINCHIP_PPP__
    #define W5100_Sn_CR_PCON          0x23
    #define W5100_Sn_CR_PDISCON       0x24
    #define W5100_Sn_CR_PCR           0x25
    #define W5100_Sn_CR_PCN           0x26
    #define W5100_Sn_CR_PCJ           0x27
#endif

/* Sn_IR values */
#ifdef __DEF_IINCHIP_PPP__
    #define W5100_Sn_IR_PRECV       0x80
    #define W5100_Sn_IR_PFAIL       0x40
    #define W5100_Sn_IR_PNEXT       0x20
#endif
#define W5100_Sn_IR_SEND_OK         0x10        /**< complete sending */
#define Sn_IR_SEND_OK               W5100_Sn_IR_SEND_OK
#define W5100_Sn_IR_TIMEOUT         0x08        /**< assert timeout */
#define Sn_IR_TIMEOUT               W5100_Sn_IR_TIMEOUT
#define W5100_Sn_IR_RECV            0x04        /**< receiving data */
#define Sn_IR_RECV                  W5100_Sn_IR_RECV
#define W5100_Sn_IR_DISCON          0x02        /**< closed socket */
#define Sn_IR_DISCON                W5100_Sn_IR_DISCON
#define W5100_Sn_IR_CON             0x01        /**< established connection */
#define Sn_IR_CON                   W5100_Sn_IR_CON

/* Sn_SR values */
#define W5100_SOCK_CLOSED           0x00        /**< closed */
#define SOCK_CLOSED                 W5100_SOCK_CLOSED
#define W5100_SOCK_INIT             0x13        /**< init state */
#define SOCK_INIT                   W5100_SOCK_INIT
#define W5100_SOCK_LISTEN           0x14        /**< listen state */
#define SOCK_LISTEN                 W5100_SOCK_LISTEN
#define W5100_SOCK_SYNSENT          0x15        /**< connection state */
#define SOCK_SYNSENT                W5100_SOCK_SYNSENT
#define W5100_SOCK_SYNRECV          0x16        /**< connection state */
#define SOCK_SYNRECV                W5100_SOCK_SYNRECV
#define W5100_SOCK_ESTABLISHED      0x17        /**< success to connect */
#define SOCK_ESTABLISHED            W5100_SOCK_ESTABLISHED
#define W5100_SOCK_FIN_WAIT         0x18        /**< closing state */
#define SOCK_FIN_WAIT               W5100_SOCK_FIN_WAIT
#define W5100_SOCK_CLOSING          0x1A        /**< closing state */
#define SOCK_CLOSING                W5100_SOCK_CLOSING
#define W5100_SOCK_TIME_WAIT        0x1B        /**< closing state */
#define SOCK_TIME_WAIT              W5100_SOCK_TIME_WAIT
#define W5100_SOCK_CLOSE_WAIT       0x1C        /**< closing state */
#define SOCK_CLOSE_WAIT             W5100_SOCK_CLOSE_WAIT
#define W5100_SOCK_LAST_ACK         0x1D        /**< closing state */
#define SOCK_LAST_ACK               W5100_SOCK_LAST_ACK
#define W5100_SOCK_UDP              0x22        /**< udp socket */
#define SOCK_UDP                    W5100_SOCK_UDP
#define W5100_SOCK_IPRAW            0x32        /**< ip raw mode socket */
#define SOCK_IPRAW                  W5100_SOCK_IPRAW
#define W5100_SOCK_MACRAW           0x42        /**< mac raw mode socket */
#define SOCK_MACRAW                 W5100_SOCK_MACRAW 
#define W5100_SOCK_PPPOE            0x5F        /**< pppoe socket */
#define SOCK_PPPOE                  W5100_SOCK_PPPOE

/* IP PROTOCOL */
#define IPPROTO_IP                  0           /**< Dummy for IP */
#define IPPROTO_ICMP                1           /**< Control message protocol */
#define IPPROTO_IGMP                2           /**< Internet group management protocol */
#define IPPROTO_GGP                 3           /**< Gateway^2 (deprecated) */
#define IPPROTO_TCP                 6           /**< TCP */
#define IPPROTO_PUP                 12          /**< PUP */
#define IPPROTO_UDP                 17          /**< UDP */
#define IPPROTO_IDP                 22          /**< XNS idp */
#define IPPROTO_ND                  77          /**< UNOFFICIAL net disk protocol */
#define IPPROTO_RAW                 255         /**< Raw IP packet */


/*********************************************************
* iinchip access function
*********************************************************/

// extern uint8 IINCHIP_READ(uint16 addr);
// extern uint8 IINCHIP_WRITE(uint16 addr,uint8 data);
// extern uint16 wiz_read_buf(uint16 addr, uint8* buf,uint16 len);
// extern uint16 wiz_write_buf(uint16 addr,uint8* buf,uint16 len);

// extern void iinchip_init(void); // reset iinchip
// extern void sysinit(uint8 tx_size, uint8 rx_size); // setting tx/rx buf size
// extern uint8 getISR(uint8 s);
// extern void putISR(uint8 s, uint8 val);
// extern uint16 getIINCHIP_RxMAX(uint8 s);
// extern uint16 getIINCHIP_TxMAX(uint8 s);
// extern uint16 getIINCHIP_RxMASK(uint8 s);
// extern uint16 getIINCHIP_TxMASK(uint8 s);

// extern uint16 getIINCHIP_RxBASE(uint8 s);
// extern uint16 getIINCHIP_TxBASE(uint8 s);

// extern void setGAR(uint8 * addr); // set gateway address
// extern void setSUBR(uint8 * addr); // set subnet mask address
// extern void clearSUBR(void);
// extern void applySUBR(void);
// extern void setSHAR(uint8 * addr); // set local MAC address
// extern void setSIPR(uint8 * addr); // set local IP address
// extern void setRTR(uint16 timeout); // set retry duration for data transmission, connection, closing ...
// extern void setRCR(uint8 retry); // set retry count (above the value, assert timeout interrupt)
// extern void setIMR(uint8 mask); // set interrupt mask.
// extern void getGAR(uint8 * addr);
// extern void getSUBR(uint8 * addr);
// extern void getSHAR(uint8 * addr);
// extern void getSIPR(uint8 * addr);
// extern uint8 getIR( void );
// extern void setSn_MSS(SOCKET s, uint16 Sn_MSSR0); // set maximum segment size
// extern void setSn_PROTO(SOCKET s, uint8 proto); // set IP Protocol value using IP-Raw mode
// extern uint8 getSn_IR(SOCKET s); // get socket interrupt status
// extern uint8 getSn_SR(SOCKET s); // get socket status
// extern uint16 getSn_TX_FSR(SOCKET s); // get socket TX free buf size
// extern uint16 getSn_RX_RSR(SOCKET s); // get socket RX recv buf size
// extern void setSn_DHAR(SOCKET s, uint8 * addr);
// extern void setSn_DIPR(SOCKET s, uint8 * addr);
// extern void setSn_DPORT(SOCKET s, uint8 * addr);
// extern void getSn_DHAR(SOCKET s, uint8 * addr);
// extern void getSn_DIPR(SOCKET s, uint8 * addr);
// extern void getSn_DPORT(SOCKET s, uint8 * addr);
// extern void setSn_TTL(SOCKET s, uint8 ttl);
// extern void setMR(uint8 val);



// #ifdef __DEF_IINCHIP_PPP__
// extern uint8 pppinit(uint8 *id, uint8 idlen, uint8 *passwd, uint8 passwdlen);
// extern uint8 pppterm(uint8 *mac,uint8 *sessionid);
// #endif

// extern void send_data_processing(SOCKET s, uint8 *data, uint16 len);
// extern void recv_data_processing(SOCKET s, uint8 *data, uint16 len);
// extern void read_data(SOCKET s, vuint8 * src, vuint8 * dst, uint16 len);
// extern void write_data(SOCKET s, vuint8 * src, vuint8 * dst, uint16 len);

#ifdef __cplusplus
}
#endif

#endif  /* _W5100_H_ */
