/**
  ******************************************************************************
  * @file    w5x00.h 
  * @author  popctrl@163.com
  * @version V1.0.0
  * @date    2014-01-08
  * @brief   
  ******************************************************************************
  * @attention
  *
  * SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT 
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM 
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  ******************************************************************************
  */

#ifndef _W5X00_H_
#define _W5X00_H_

#ifdef __cplusplus
extern "C" {
#endif 

/*----------------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>

#include "use_mcu_types.h"
#include "tcpip_chip_types.h"
#include "tcpip_chip_spi_ctrl.h"
#include "net_msg_cfg.h"
#include "HEEC_cfg.h"

#ifdef __DEF_IINCHIP_PPP__
   #include "md5.h"
#endif

#define WINDOWFULL_FLAG_ON 1
#define WINDOWFULL_FLAG_OFF 0
#define WINDOWFULL_MAX_RETRY_NUM 3
#define WINDOWFULL_WAIT_TIME 1000

#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__) || (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__)
  #define ADDR_INCREASE_1       1
  #define ADDR_INCREASE_2       2
  #define ADDR_INCREASE_3       3
  #define ADDR_INCREASE_4       4
  #define ADDR_INCREASE_5       5
  #define ADDR_INCREASE_6       6
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
  #define ADDR_INCREASE_1       (1<<8)
  #define ADDR_INCREASE_2       (2<<8)
  #define ADDR_INCREASE_3       (3<<8)
  #define ADDR_INCREASE_4       (4<<8)
  #define ADDR_INCREASE_5       (5<<8)
  #define ADDR_INCREASE_6       (6<<8)
#endif
/*----------------------------------------------------------------------------*/

extern uint8 incr_windowfull_retry_cnt(uint8 s);
extern void init_windowfull_retry_cnt(uint8 s);

extern void clearSUBR(void);
extern void getGAR(uint8 * addr);
extern void getSUBR(uint8 * addr);
extern void getSHAR(uint8 * addr);
extern void getSIPR(uint8 * addr);

extern uint8 getIR( void );
extern void setSn_MSS(SOCKET s, uint16 Sn_MSSR0); // set maximum segment size
extern void setSn_PROTO(SOCKET s, uint8 proto); // set IP Protocol value using IP-Raw mode
extern uint8 getSn_IR(SOCKET s); // get socket interrupt status
extern uint8 getSn_SR(SOCKET s); // get socket status
extern uint16 getSn_TX_FSR(SOCKET s); // get socket TX free buf size
extern uint16 getSn_RX_RSR(SOCKET s); // get socket RX recv buf size
extern uint8 getSn_SR(SOCKET s);
extern void setSn_TTL(SOCKET s, uint8 ttl);

extern uint16 getIINCHIP_RxMAX(uint8 s);
extern uint16 getIINCHIP_TxMAX(uint8 s);
extern uint16 getIINCHIP_RxMASK(uint8 s);
extern uint16 getIINCHIP_TxMASK(uint8 s);
// extern uint16 getIINCHIP_RxBASE(uint8 s);
// extern uint16 getIINCHIP_TxBASE(uint8 s);
extern uint32 getIINCHIP_RxBASE(uint8 s);
extern uint32 getIINCHIP_TxBASE(uint8 s);


extern void send_data_processing(SOCKET s, uint8 *wizdata, uint16 len);
extern void recv_data_processing(SOCKET s, uint8 *wizdata, uint16 len);

extern void write_data(SOCKET s, vuint8 * src, vuint8 * dst, uint16 len);
extern void read_data(SOCKET s, vuint8 * src, vuint8 * dst, uint16 len);

#ifdef __DEF_IINCHIP_PPP__
extern uint8 pppinit(uint8 *id, uint8 idlen, uint8 *passwd, uint8 passwdlen);
extern uint8 pppterm(uint8 *mac,uint8 *sessionid);
#endif

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif      /* _W5X00_H_ */

/********************** (C) COPYRIGHT 2014 popctrl@163.com *****END OF FILE****/
