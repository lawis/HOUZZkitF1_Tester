/**
  ******************************************************************************
  * @file    main.c 
  * @author  popctrl@163.com
  * @version V0.1
  * @date    2014-05-12
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT 
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM 
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  ******************************************************************************
  */  

/* Includes ------------------------------------------------------------------*/

#include "main.h"

/** @addtogroup mcu51x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
//  #define TEST_W5X00_PING

/* Private macro -------------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/


/* Private function prototypes -----------------------------------------------*/



/* Private functions ---------------------------------------------------------*/


/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{

//  vHEEC_SPI_init();
//  HEEC_RST_LowLevel_Init();
    HEEC_Reset();

    Set_network();

    presentTime = my_time; // For TCP client's connection request delay

    while(1) {
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)
        loopback_tcps(0, 5000);
        loopback_tcps(1, 5001);
        loopback_tcpc(2, 5004);
        loopback_udp(3, 3000);
        my_time++;
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__) || (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
        loopback_tcps(0, 5000);
        loopback_tcps(1, 5001);
        loopback_tcps(2, 5002);
        loopback_tcps(3, 5003);
        loopback_tcpc(4, 5004);
        loopback_udp(5, 3000);
        loopback_udp(6, 3001);
        loopback_udp(7, 3002);
        my_time++;
#endif
    }
}

/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
//PUTCHAR_PROTOTYPE
//{
//  /* Place your implementation of fputc here */
//  /* e.g. write a character to the USART */
//  USART_SendData(EVAL_COM1, (uint8_t) ch);

//  /* Loop until the end of transmission */
//  while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET)
//  {}

//  return ch;
//}








/*----------------------------------------------------------------------------*/

/**
  * @}
  */


/********************** (C) COPYRIGHT 2014 popctrl@163.com *****END OF FILE****/
