/***********************************************************************************
�ɶ���Ȼ�������޹�˾
�绰��028-86127089��400-998-5300
���棺028-86127039
��ַ��http://www.hschip.com.cn
��дʱ�䣺2013-9-5
***********************************************************************************/

#include"config.h"

typedef  unsigned char SOCKET;
#define S_RX_SIZE	2048
#define S_TX_SIZE	2048

extern void Delay(unsigned int d);		/* Delay d*1ms */

/******************************* W5500 Write Operation *******************************/
/* Write W5500 Common Register a byte */
void Write_1_Byte(unsigned short reg, unsigned char dat)
{
	/* Set W5500 SCS Low */
	W5500_SCS_CLR(); 	
	/* Write Address */
	SPI1_SendData(reg/256);
	SPI1_SendData(reg);
	/* Write Control Byte */
	SPI1_SendData(FDM1|RWB_WRITE|COMMON_R);
	/* Write 1 byte */
	SPI1_SendData(dat);
	/* Set W5500 SCS High */
	W5500_SCS_SET();
}

/* Write W5500 Common Register 2 bytes */
void Write_2_Byte(unsigned short reg, unsigned short dat)
{
	/* Set W5500 SCS Low */
	W5500_SCS_CLR(); 	
	/* Write Address */
	SPI1_SendData(reg/256);
	SPI1_SendData(reg);
	/* Write Control Byte */
	SPI1_SendData(FDM2|RWB_WRITE|COMMON_R);
	/* Write 2 bytes */
	SPI1_SendData(dat/256);
	SPI1_SendData(dat);
	/* Set W5500 SCS High */
	W5500_SCS_SET();
}

/* Write W5500 Common Register n bytes */
void Write_Bytes(unsigned short reg, unsigned char *dat_ptr, unsigned short size)
{
	unsigned short i;

	/* Set W5500 SCS Low */
	W5500_SCS_CLR(); 		
	/* Write Address */
	SPI1_SendData(reg/256);
	SPI1_SendData(reg);
	/* Write Control Byte */
	SPI1_SendData(VDM|RWB_WRITE|COMMON_R);

	/* Write n bytes */
	for(i=0;i<size;i++)
	{
		SPI1_SendData(*dat_ptr);
		dat_ptr++;
	}

	/* Set W5500 SCS High */
	W5500_SCS_SET();
}

/* Write W5500 Socket Register 1 byte */
void Write_SOCK_1_Byte(SOCKET s, unsigned short reg, unsigned char dat)
{
	/* Set W5500 SCS Low */
	W5500_SCS_CLR(); 		
	/* Write Address */
	SPI1_SendData(reg/256);
	SPI1_SendData(reg);
	/* Write Control Byte */
	SPI1_SendData(FDM1|RWB_WRITE|(s*0x20+0x08));
	/* Write 1 byte */
	SPI1_SendData(dat);
	/* Set W5500 SCS High */
	W5500_SCS_SET();
}

/* Write W5500 Socket Register 2 byte */
void Write_SOCK_2_Byte(SOCKET s, unsigned short reg, unsigned short dat)
{
	/* Set W5500 SCS Low */
	W5500_SCS_CLR(); 		
	/* Write Address */
	SPI1_SendData(reg/256);
	SPI1_SendData(reg);
	/* Write Control Byte */
	SPI1_SendData(FDM2|RWB_WRITE|(s*0x20+0x08));
	/* Write 2 bytes */
	SPI1_SendData(dat/256);
	SPI1_SendData(dat);
	/* Set W5500 SCS High */
	W5500_SCS_SET();
}

/* Write W5500 Socket Register 2 byte */
void Write_SOCK_4_Byte(SOCKET s, unsigned short reg, unsigned char *dat_ptr)
{
	/* Set W5500 SCS Low */
	W5500_SCS_CLR(); 	
	
	/* Write Address */
	SPI1_SendData(reg/256);
	SPI1_SendData(reg);

	/* Write Control Byte */
	SPI1_SendData(FDM4|RWB_WRITE|(s*0x20+0x08));
	
	/* Write 4 bytes */
	SPI1_SendData(*dat_ptr);	
	dat_ptr++;
	SPI1_SendData(*dat_ptr);
	dat_ptr++;
	SPI1_SendData(*dat_ptr);
	dat_ptr++;
	SPI1_SendData(*dat_ptr);

	/* Set W5500 SCS High */
	W5500_SCS_SET();
}

/******************************* W5500 Read Operation *******************************/
/* Read W5500 Common register 1 Byte */
unsigned char Read_1_Byte(unsigned short reg)
{
	unsigned char i;

	/* Set W5500 SCS Low */
	W5500_SCS_CLR(); 	

	/* Write Address */
	SPI1_SendData(reg/256);
	SPI1_SendData(reg);

	/* Write Control Byte */
	SPI1_SendData(FDM1|RWB_READ|COMMON_R);
	
	/* Read 1 byte */
	i=SPI1_RcvData();

	/* Set W5500 SCS High*/
	W5500_SCS_SET();
	return i;
}

/* Read W5500 Socket register 1 Byte */
unsigned char Read_SOCK_1_Byte(SOCKET s, unsigned short reg)
{
	unsigned char i;

	/* Set W5500 SCS Low */
	W5500_SCS_CLR();

	/* Write Address */
	SPI1_SendData(reg/256);
	SPI1_SendData(reg);

	/* Write Control Byte */
	SPI1_SendData(FDM1|RWB_READ|(s*0x20+0x08));
	
	/* Read 1 byte */
	i=SPI1_RcvData();

	/* Set W5500 SCS High*/
	W5500_SCS_SET();
	return i;
}

/* Read W5500 Socket register 2 Bytes (short) */
unsigned short Read_SOCK_2_Byte(SOCKET s, unsigned short reg)
{
	unsigned short i;

	/* Set W5500 SCS Low */
	W5500_SCS_CLR();

	/* Write Address */
	SPI1_SendData(reg/256);
	SPI1_SendData(reg);

	/* Write Control Byte */
	SPI1_SendData(FDM2|RWB_READ|(s*0x20+0x08));

	/* Read 2 byte */
	i=SPI1_RcvData();
	i*=256;
	i+=SPI1_RcvData();

	/* Set W5500 SCS High*/
	W5500_SCS_SET();
	return i;
}

/******************** Read data from W5500 Socket data RX Buffer *******************/
unsigned short Read_SOCK_Data_Buffer(SOCKET s, unsigned char *dat_ptr)
{
	unsigned short rx_size;
	unsigned short offset, offset1;
	unsigned short i;
	unsigned char j;

	rx_size=Read_SOCK_2_Byte(s,Sn_RX_RSR);
	if(rx_size==0)		/* if no data received, return */
		return 0;
	if(rx_size>1460)
		rx_size=1460;

	offset=Read_SOCK_2_Byte(s,Sn_RX_RD);
	offset1=offset;
	offset&=(S_RX_SIZE-1);		/* Calculate the real physical address */

	/* Set W5500 SCS Low */
	W5500_SCS_CLR();

	/* Write Address */
	SPI1_SendData(offset/256);
	SPI1_SendData(offset);

	/* Write Control Byte */
	SPI1_SendData(VDM|RWB_READ|(s*0x20+0x18));		/* Read variable size */
	j=SPI1_RcvData();;
	
	if((offset+rx_size)<S_RX_SIZE)
	{
		/* Read Data */
		for(i=0;i<rx_size;i++)
		{
			j=SPI1_RcvData();;
			*dat_ptr=j;
			dat_ptr++;
		}
	}
	else
	{
		offset=S_RX_SIZE-offset;
		for(i=0;i<offset;i++)
		{
			j=SPI1_RcvData();;
			*dat_ptr=j;
			dat_ptr++;
		}
		/* Set W5500 SCS High*/
		W5500_SCS_SET();

		/* Set W5500 SCS Low */
		W5500_SCS_CLR();
		/* Write Address */
		SPI1_SendData(0x00);
		SPI1_SendData(0x00);
		/* Write Control Byte */
		SPI1_SendData(VDM|RWB_READ|(s*0x20+0x18));		/* Read variable size */
		j=SPI1_RcvData();
		/* Read Data */
		for(;i<rx_size;i++)
		{
			j=SPI1_RcvData();;
			*dat_ptr=j;
			dat_ptr++;
		}
	}
	/* Set W5500 SCS High*/
	W5500_SCS_SET();

	/* Update offset*/
	offset1+=rx_size;
	Write_SOCK_2_Byte(s, Sn_RX_RD, offset1);
	Write_SOCK_1_Byte(s, Sn_CR, RECV);					/* Write RECV Command */
	return rx_size;
}

/******************** Write data to W5500 Socket data TX Buffer *******************/
void Write_SOCK_Data_Buffer(SOCKET s, unsigned char *dat_ptr, unsigned short size)
{
	unsigned short offset,offset1;
	unsigned short i;

	offset=Read_SOCK_2_Byte(s,Sn_TX_WR);
	offset1=offset;
	offset&=(S_TX_SIZE-1);		/* Calculate the real physical address */

	/* Set W5500 SCS Low */
	W5500_SCS_CLR();

	/* Write Address */
	SPI1_SendData(offset/256);
	SPI1_SendData(offset);

	/* Write Control Byte */
	SPI1_SendData(VDM|RWB_WRITE|(s*0x20+0x10));		/* Read variable size */

	if((offset+size)<S_TX_SIZE)
	{
		/* Write Data */
		for(i=0;i<size;i++)
		{
			SPI1_SendData(*dat_ptr);		/* Send a byte*/		
			dat_ptr++;
		}
	}
	else
	{
		offset=S_TX_SIZE-offset;
		for(i=0;i<offset;i++)
		{
			SPI1_SendData(*dat_ptr); 		/* Send a byte */
			dat_ptr++;
		}
		/* Set W5500 SCS High*/
		W5500_SCS_SET();

		/* Set W5500 SCS Low */
		W5500_SCS_CLR();
		/* Write Address */
		SPI1_SendData(0x00);
		SPI1_SendData(0x00);
		/* Write Control Byte */
		SPI1_SendData(VDM|RWB_WRITE|(s*0x20+0x10));		/* Read variable size */
		/* Read Data */
		for(;i<size;i++)
		{
			SPI1_SendData(*dat_ptr);		/* Send a byte */		
			dat_ptr++;
		}
	}
	/* Set W5500 SCS High*/
	W5500_SCS_SET();

	/* Updata offset */
	offset1+=size;
	Write_SOCK_2_Byte(s, Sn_TX_WR, offset1);
	Write_SOCK_1_Byte(s, Sn_CR, SEND);					/* Write SEND Command */
}

/*********************** Set Socket n in TCP Client mode ************************/
unsigned int Socket_Connect(SOCKET s)
{
	/* Set Socket n in TCP mode */
	Write_SOCK_1_Byte(s,Sn_MR,MR_TCP);
	/* Open Socket n */
	Write_SOCK_1_Byte(s,Sn_CR,OPEN);

	Delay(5);	/* Wait for a moment */
	if(Read_SOCK_1_Byte(s,Sn_SR)!=SOCK_INIT)
	{
		Write_SOCK_1_Byte(s,Sn_CR,CLOSE);		/* Close Socket n */
		return FALSE;
	}

	/* Set Socket n in Server mode */
	Write_SOCK_1_Byte(s,Sn_CR,CONNECT);
	return TRUE;
}
