/******************************************************
Chengdu Hasion Electronics Co., Ltd
Website: http://wwww.hschip.com
2013-08-12
******************************************************/

#define TRUE	0xffffffff
#define FALSE	0x00000000

#define S_RX_SIZE	2048
#define S_TX_SIZE	2048

typedef  unsigned char SOCKET;


extern void System_Initialization(void);

/* Write W5500 Common Register a byte */
extern void Write_1_Byte(unsigned short reg, unsigned char dat);
/* Write W5500 Common Register 2 bytes */
extern void Write_2_Byte(unsigned short reg, unsigned short dat);
/* Write W5500 Common Register n bytes */
extern void Write_Bytes(unsigned short reg, unsigned char *dat_ptr, unsigned short size);

/* Write W5500 Socket Register 1 byte */
extern void Write_SOCK_1_Byte(SOCKET s, unsigned short reg, unsigned char dat);
/* Write W5500 Socket Register 2 byte */
extern void Write_SOCK_2_Byte(SOCKET s, unsigned short reg, unsigned short dat);
/* Write W5500 Socket Register 2 byte */
extern void Write_SOCK_4_Byte(SOCKET s, unsigned short reg, unsigned char *dat_ptr);

/* Read W5500 Common register 1 Byte */
extern unsigned char Read_1_Byte(unsigned short reg);

/* Read W5500 Socket register 1 Byte */
extern unsigned char Read_SOCK_1_Byte(SOCKET s, unsigned short reg);
/* Read W5500 Socket register 2 Bytes (short) */
extern unsigned short Read_SOCK_2_Byte(SOCKET s, unsigned short reg);

/* Read data from W5500 Socket data RX Buffer */
extern unsigned short Read_SOCK_Data_Buffer(SOCKET s, unsigned char *dat_ptr);
/* Write data to W5500 Socket data TX Buffer */
extern void Write_SOCK_Data_Buffer(SOCKET s, unsigned char *dat_ptr, unsigned short size);

/* Set Socket n in TCP Client mode */
extern unsigned int Socket_Connect(SOCKET s);
