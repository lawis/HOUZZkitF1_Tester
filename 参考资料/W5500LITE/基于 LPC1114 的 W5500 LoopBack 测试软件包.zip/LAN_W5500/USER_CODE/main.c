
#include  "config.h"                                                    /* LPC17xx����Ĵ���            */

//TCPC
/*�����������*/
//���أ�192.168.1.1
//����:	255.255.255.0
//������ַ��48 53 00 57 55 00
//����IP��ַ:192.168.1.42
//�˿�0�Ķ˿ںţ�5000
//�˿�0��Ŀ��IP��ַ��192.168.1.10
//�˿�0��Ŀ�Ķ˿ںţ�6000
/*********************************************************************************************************
	�궨��
*********************************************************************************************************/


/************************************************************************************************************
						ȫ�ֱ���
************************************************************************************************************/
unsigned int Timer2_Counter;

unsigned int S0_SendOK=1;
unsigned int S0_TimeOut=0;

unsigned short S0_Port=5000;//�˿�0�Ķ˿ںţ�5000

unsigned char S_Data_Buffer[2048];
unsigned char test;
/*********************************************************************************************************
** Function name:       Delayms
** Descriptions:        ������ʱ
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void Delay (uint32 ulTime)
{
	uint32_t i;		
	i = 0;
	while (ulTime--) 
	{
		for (i = 0; i < 5000; i++);
	}
}

void W5200_GPIO_Configuration(void)
{
 	LPC_SYSCON->SYSAHBCLKCTRL |= (1 << 6);                              /* ��ʼ��GPIO AHBʱ��           */
  LPC_SYSCON->SYSAHBCLKCTRL |= (1 << 16);                             /* ʹ��IOCONʱ��                */

	/* W5500_SCS���ų�ʼ������) */
	LPC_IOCON->PIO1_6  &= ~0x07;                                        /* ��IO��ʼ��ΪGPIO����         */	
	LPC_GPIO1->DIR     |= W5500_SCS;                                    /* ��IO��ʼ��Ϊ�������         */
	
	/* W5500_RST���ų�ʼ������ */
	LPC_IOCON->PIO1_7  &= ~0x07;                                        /* ��IO��ʼ��ΪGPIO����         */	
	LPC_GPIO1->DIR     |= W5500_RST;                                    /* ��IO��ʼ��Ϊ�������         */	
	
	/* W5500_INT���ų�ʼ������(P0.4) */	
	LPC_IOCON->PIO0_4 &= ~0x07;                                         /* ��IO��ʼ��ΪGPIO����         */	
	LPC_GPIO0->DIR    &= ~W5500_INT;                                    /* ��IO��ʼ��Ϊ���빦��         */ 			
}

/* W5500 configuration */
void W5500_Configuration()
{
	unsigned char array[6];

//	while((Read_1_Byte(PHYCFGR)&LINK)==0); 		/* Waiting for Ethernet Link */

	Write_1_Byte(MR, RST);
	Delay(10);

	array[0]=192;//�������ز���
	array[1]=168;
	array[2]=1;
	array[3]=1;
	Write_Bytes(GAR, array, 4);
	
	array[0]=255;//������������
	array[1]=255;
	array[2]=255;
	array[3]=0;
	Write_Bytes(SUBR, array, 4);

	array[0]=0x48;//����������ַ
	array[1]=0x53;
	array[2]=0x00;
	array[3]=0x57;
	array[4]=0x55;
	array[5]=0x00;
	Write_Bytes(SHAR, array, 6);
	
	array[0]=192;//���ر���IP��ַ
	array[1]=168;
	array[2]=1;
	array[3]=42;
	Write_Bytes(SIPR, array, 4);
}

void Socket0_Config(void)
{
	unsigned char array[4];

	Write_SOCK_2_Byte(0, Sn_PORT, S0_Port);//���ö˿�0�Ķ˿ں�

	array[0]=192;//���ö˿�0Ŀ��(Զ��)IP��ַ
	array[1]=168;
	array[2]=1;
	array[3]=10;
	Write_SOCK_4_Byte(0, Sn_DIPR, array);

	Write_SOCK_2_Byte(0, Sn_DPORTR, 6000);//���ö˿�0Ŀ��(Զ��)�˿ں�

	/* Set Maximum Segment Size as 1460 */
	Write_SOCK_2_Byte(0, Sn_MSSR, 1460);

	/* Set RX Buffer Size as 2K */
	Write_SOCK_1_Byte(0,Sn_RXBUF_SIZE, 0x02);
	/* Set TX Buffer Size as 2K */
	Write_SOCK_1_Byte(0,Sn_TXBUF_SIZE, 0x02);
}

/********* Process IR Register ********/
void Process_IR(void)
{
	unsigned char i;

	i=Read_1_Byte(SIR);
	if(i&0x01)
	{
		i=Read_SOCK_1_Byte(0,Sn_IR);
		Write_SOCK_1_Byte(0,Sn_IR,i);		/* Clear IR flag */

		if(i&IR_CON)		/* TCP CONNECT established */
		{;
// 			GPIO_ResetBits(GPIOC, D_OUTPUT2);		/* Turn on LED */
		}
		if(i&IR_DISCON)		/* TCP Disconnect */
		{
			Write_SOCK_1_Byte(0,Sn_CR,CLOSE);		/* Close Socket 0 */
			;//GPIO_SetBits(GPIOC, D_OUTPUT2); 		/* Turn off LED */
		}
		if(i&IR_TIMEOUT)
		{
			S0_TimeOut=1;
			Write_SOCK_1_Byte(0,Sn_CR,CLOSE);		/* Close Socket 0 */
			;//GPIO_SetBits(GPIOC, D_OUTPUT2); 		/* Turn off LED */
		}
		if(i&IR_SEND_OK)
		{
			S0_SendOK=1;
		}
	}
}

/****************************** Detect Gateway **********************************/
/* If Gateway detected, retuen true                                             */
/* If no Gateway detected, return false                                         */
/* If no need to detect Gateway, skip this procedure                            */
/********************************************************************************/
unsigned int Detect_Gateway(void)
{
//	unsigned char array[4];

// 	/* Set Socket 0 detsination IP as SIP+1 */
// 	array[0]=192+1;
// 	array[1]=168+1;
// 	array[2]=1+1;
// 	array[3]=10+1;
// 	Write_SOCK_4_Byte(0,Sn_DIPR, array);

	/* Set Socket 0 in TCP mode */
	Write_SOCK_1_Byte(0,Sn_MR,MR_TCP);//����socket0ΪTCPģʽ
	/* Open Socket 0 */
	Write_SOCK_1_Byte(0,Sn_CR,OPEN);//��socket0

	Delay(5);	/* Wait for a moment */
	if(Read_SOCK_1_Byte(0,Sn_SR)!=SOCK_INIT)
	{
		Write_SOCK_1_Byte(0,Sn_CR,CLOSE);		/* Close Socket 0 */
		return FALSE;
	}
	
	Write_SOCK_1_Byte(0,Sn_CR,CONNECT);			/* Initial a TCP CONNECT */

	do
	{
		Process_IR();
		if(S0_TimeOut)
		{
			S0_TimeOut=0;
			return FALSE;		/* No Gateway detected */
		}
		else if(Read_SOCK_1_Byte(0,Sn_DHAR)!=0xff)
		{
			Write_SOCK_1_Byte(0,Sn_CR,CLOSE);		/* Close Socket 0 */
			return TRUE;							/* Gateway detected */
		}
	}while(1);
}

/********** Loop Back test *********/
void Process_LoopBack(void)
{
	unsigned short i;

	/* Read Data from RX buffer */
	i=Read_SOCK_Data_Buffer(0, S_Data_Buffer);
	if(i==0)
		return;

	/* Write Data to TX Buffer */
	while((S0_SendOK==0)&&(S0_TimeOut==0))
		Process_IR();

	if(S0_SendOK==1)
	{
		S0_SendOK=0;
		Write_SOCK_Data_Buffer(0, S_Data_Buffer, i);
	}
	else
	{
		S0_TimeOut=0;
	}
}

/*****************************************************************
                           Main Program
*****************************************************************/
int main(void)
{
	unsigned char i;

	SystemInit();                                                       /* ϵͳ��ʼ��������ɾ��         */
	W5200_GPIO_Configuration();
 	SSP1PinInit();                                                       /*  ���ų�ʼ��                  */	
  SPI1Master_Init();		
	Delay(2000);

	W5500_RST_CLR();
	Delay(100);
	W5500_RST_SET();
	Delay(100);
	
	/* Config W5500 */
	W5500_Configuration();

	/* ������أ����û�б�Ҫ������أ�������һ���� */
	if(Detect_Gateway()==TRUE)
		;
// 		GPIO_ResetBits(GPIOC, D_OUTPUT1);
			
	/* Using Socket 0 */
	Socket0_Config();

	while(1)
	{
		Process_IR();

		i=Read_SOCK_1_Byte(0,Sn_SR);
		if(i==0)
		{
			do
			{
				Delay(1000);
				/* set Socket n Port Number as 5000 */
				Write_SOCK_2_Byte(0, Sn_PORT, S0_Port);
			}while(Socket_Connect(0)==FALSE);

			S0_Port++;		/* Change Socket 0 Port Number for next CONNECT */
			if(S0_Port>6000)
				S0_Port=5000;
		}
		else if(i==SOCK_ESTABLISHED)
		{
			Process_LoopBack();
		}
		else if(S0_TimeOut)
		{
			S0_TimeOut=0;
		}	
	}
}

/*********************************************************************************************************
	End Of File
*********************************************************************************************************/
