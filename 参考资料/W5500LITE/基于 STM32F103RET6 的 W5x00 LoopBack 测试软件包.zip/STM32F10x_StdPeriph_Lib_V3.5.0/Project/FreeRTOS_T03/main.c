/**
  ******************************************************************************
  * @file    Project/FreeRTOS_T03/main.c 
  * @author  popctrl@163.com
  * @version V0.1
  * @date    2014-01-01
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT 
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM 
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  ******************************************************************************
  */  

/* Includes ------------------------------------------------------------------*/

#include "main.h"

/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#ifdef USE_STM3210E_EVAL
  #define MESSAGE1   " STM32 High Density " 
  #define MESSAGE2   " Device running on  " 
  #define MESSAGE3   "   STM3210E-EVAL    " 
#elif defined (USE_STM32F103RET6_LITE)
  #define MESSAGE1   "STM32 High Density, " 
  #define MESSAGE2   "Device running on..." 
  #define MESSAGE3   "STM32F103RET6-Lite  " 
#endif

//#define TEST_W5X00_PING

/*--------------- Tasks Priority -------------*/
//#define DHCP_TASK_PRIO   ( tskIDLE_PRIORITY + 2 )
#define mainCREATOR_TASK_PRIORITY       ( tskIDLE_PRIORITY + 4 )      
#define TESTCOM_TASK2_PRIO              ( tskIDLE_PRIORITY + 3 )
#define TESTCOM_TASK1_PRIO              ( tskIDLE_PRIORITY + 2 )


/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
 USART_InitTypeDef USART_InitStructure;

/* Private function prototypes -----------------------------------------------*/
#ifdef __GNUC__
/* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
   set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */



void NVIC_Configuration(void);
void Timer_Configuration(void);
//void LCD_LED_Init(void);
void TestCOMtask2(void * pvParameters);
void TestCOMtask1(void * pvParameters);

/* Private functions ---------------------------------------------------------*/


/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{
  /*!< At this stage the microcontroller clock setting is already configured, 
       this is done through SystemInit() function which is called from startup
       file (startup_stm32f10x_xx.s) before to branch to application main.
       To reconfigure the default setting of SystemInit() function, refer to
       system_stm32f10x.c file
     */     

  /* Initialize LEDs, Key Button, LCD and COM port(USART) available on
     STM3210X-EVAL board ******************************************************/
//   STM_EVAL_LEDInit(LED1);
//   STM_EVAL_LEDInit(LED2);
//   STM_EVAL_LEDInit(LED3);
//   STM_EVAL_LEDInit(LED4);

  /* USARTx configured as follow:
        - BaudRate = 115200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
  */
  USART_InitStructure.USART_BaudRate = 115200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  STM_EVAL_COMInit(COM1, &USART_InitStructure);

  /* Initialize the LCD */
#ifdef USE_STM32100B_EVAL
  STM32100B_LCD_Init();
#elif defined (USE_STM3210E_EVAL)
  STM3210E_LCD_Init(); 
#elif defined (USE_STM32F103RET6_LITE)

#endif

//  MCO_LowLevel_Init();
  HEEC_SPI_init();
  HEEC_RST_LowLevel_Init();
  HEEC_Reset();

  Set_network();

  /* Retarget the C library printf function to the USARTx, can be USART1 or USART2
     depending on the EVAL board you are using ********************************/
  printf("\r\n\r\nSTM32F103RET6 Lite EVB.\r\n");
  printf("SystemCoreClock = %d Hz.\r\n",SystemCoreClock);
  printf("SPI1 <-> W5x00 Test.\r\n\r\n");

  printf("�ļ�����ʱ��\r\n" ); 
  printf("File : %s\r\n", __FILE__);
  printf("Date : %s\r\n", __DATE__);
  printf("Time : %s\r\n", __TIME__);
  printf("Line : %d\r\n", __LINE__);

  NVIC_Configuration();
  Timer_Configuration();

#ifdef TEST_W5X00_PING
  printf("\r\nTest W5x00 ping request.\r\n");
  while(1);
#endif

    presentTime = my_time; // For TCP client's connection request delay

    while(1) {
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5100__)
        loopback_tcps(0, 5000);
        loopback_tcps(1, 5001);
        loopback_tcpc(2, 5004);
        loopback_udp(3, 3000);
#endif
#if (__TCPIP_CHIP_TYPE__ == __CHIP_W5200__) || (__TCPIP_CHIP_TYPE__ == __CHIP_W5500__)
        loopback_tcps(0, 5000);
        loopback_tcps(1, 5001);
        loopback_tcps(2, 5002);
        loopback_tcps(3, 5003);
        loopback_tcpc(4, 5004);
        loopback_udp(5, 3000);
        loopback_udp(6, 3001);
        loopback_udp(7, 3002);
#endif
    }

  /* Turn on leds available on STM3210X-EVAL **********************************/
//   STM_EVAL_LEDOn(LED1);
//   STM_EVAL_LEDOn(LED2);
//   STM_EVAL_LEDOn(LED3);
//   STM_EVAL_LEDOn(LED4);

  /* Add your application code here
     */
  xTaskCreate(TestCOMtask1, ( signed portCHAR * )"TCOMtask1", configMINIMAL_STACK_SIZE*2, NULL, TESTCOM_TASK1_PRIO, NULL);
  xTaskCreate(TestCOMtask2, ( signed portCHAR * )"TCOMtask2", configMINIMAL_STACK_SIZE*2, NULL, TESTCOM_TASK2_PRIO, NULL);

  /* The suicide tasks must be created last as they need to know how many
     tasks were running prior to their creation in order to ascertain whether
     or not the correct/expected number of tasks are running at any given time. */
  //vCreateSuicidalTasks( mainCREATOR_TASK_PRIORITY );

  /* Start scheduler */
  vTaskStartScheduler();

  /* Infinite loop */
  while (1)
  {
  }
}

/**
  * @brief  Retargets the C library printf function to the USART.
  * @param  None
  * @retval None
  */
PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the USART */
  USART_SendData(EVAL_COM1, (uint8_t) ch);

  /* Loop until the end of transmission */
  while (USART_GetFlagStatus(EVAL_COM1, USART_FLAG_TC) == RESET)
  {}

  return ch;
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @brief  Test COM1 task
  * @param  pvParameters not used
  * @retval None
  */
void TestCOMtask1(void * pvParameters)
{
  for( ;; )
  {
    /* Test COM1 each 100*10ms */
    printf("\r\nTest COM task01.\r\n");
    vTaskDelay(100);
  }
}

/**
  * @brief  Test COM1 task
  * @param  pvParameters not used
  * @retval None
  */
void TestCOMtask2(void * pvParameters)
{
  for( ;; )
  {
    /* Test COM1 each 150*10ms */
    printf("\r\nTest COM task02.\r\n");
    vTaskDelay(150);
  }
}

/*----------------------------------------------------------------------------*/
/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configures Vector Table base location.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;

#ifdef  VECT_TAB_RAM
  /* Set the Vector Table base location at 0x20000000 */
  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0);

#else  /* VECT_TAB_FLASH  */
  /* Configure one bit for preemption priority */
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);

  /* Enable the USART1 Interrupt */
//   NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
//   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//   NVIC_Init(&NVIC_InitStructure);

  /* Enable the USART2 Interrupt */
//   NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
//   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//   NVIC_Init(&NVIC_InitStructure);


  /* Enable the TIM2 global Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

   /* Enable the TIM2 global Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  /* Enable the TIM2 global Interrupt */
//   NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
//   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
//   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;

//  NVIC_Init(&NVIC_InitStructure);

  /* Set the Vector Table base location at 0x08000000 */
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);

  /* Set the Vector Table base location at 0x08002000 -> USE AIP*/
  // NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x2000);
  // NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x4000);
#endif
}

void Timer_Configuration(void)
{

  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

  /* TIM2 clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

  /* Time base configuration */
  TIM_TimeBaseStructure.TIM_Period = 2000;
  TIM_TimeBaseStructure.TIM_Prescaler = 0;
  TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

  /* Prescaler configuration */
  TIM_PrescalerConfig(TIM2, 71, TIM_PSCReloadMode_Immediate);

  /* TIM enable counter */
  TIM_Cmd(TIM2, ENABLE);

  /* TIM IT enable */
  TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

}
/**
  * @}
  */


/********************** (C) COPYRIGHT 2014 popctrl@163.com *****END OF FILE****/
