/**
  ******************************************************************************
  * @file    main.h 
  * @author  popctrl@163.com
  * @version V1.0.0
  * @date    2014-01-08
  * @brief   
  ******************************************************************************
  * @attention
  *
  * SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT 
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM 
  * THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2014 popctrl@163.com</center></h2>
  ******************************************************************************
  */

#ifndef _MAIN_H_
#define _MAIN_H_

#ifdef __cplusplus
extern "C" {
#endif 

/*----------------------------------------------------------------------------*/

#include <stdio.h>
#include "stm32f10x.h"
#include "stm32_eval.h"

#include "FreeRTOS.h"
#include "task.h"

#include "use_mcu_types.h"
#include "tcpip_chip_types.h"
#include "tcpip_chip_spi_ctrl.h"
#include "net_msg_cfg.h"
#include "HEEC_cfg.h"

#include "loopback_w5x00.h"

/*----------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif      /* _MAIN_H_ */

/********************** (C) COPYRIGHT 2014 popctrl@163.com *****END OF FILE****/
